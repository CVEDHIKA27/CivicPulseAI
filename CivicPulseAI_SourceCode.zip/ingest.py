
from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


# Project paths
PROJECT_ROOT = Path(__file__).resolve().parents[3]

DOCUMENTS_DIR = PROJECT_ROOT / "documents" / "municipal_guidelines"
VECTOR_DB_DIR = PROJECT_ROOT / "data" / "chroma_db"

# Local embedding model
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# ChromaDB collection
COLLECTION_NAME = "civicpulse_municipal_knowledge"

# Text chunk settings
CHUNK_SIZE = 900
CHUNK_OVERLAP = 150


def split_text(text: str) -> list[str]:
    """Split a document into overlapping text chunks."""

    text = text.strip()
    chunks = []

    start = 0

    while start < len(text):
        end = min(start + CHUNK_SIZE, len(text))

        # Prefer ending a chunk at a word boundary.
        if end < len(text):
            boundary = text.rfind(" ", start, end)
            if boundary > start:
                end = boundary

        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        if end >= len(text):
            break

        start = max(end - CHUNK_OVERLAP, start + 1)

    return chunks


def main():
    print("CivicPulse AI - RAG Document Ingestion")
    print("-" * 45)

    # Check document folder
    if not DOCUMENTS_DIR.exists():
        raise FileNotFoundError(
            f"Knowledge document folder not found: {DOCUMENTS_DIR}"
        )

    files = sorted(DOCUMENTS_DIR.glob("*.txt"))

    if not files:
        raise FileNotFoundError(
            "No .txt knowledge documents found."
        )

    print(f"Documents found: {len(files)}")

    # Load the local embedding model
    print(f"\nLoading embedding model: {MODEL_NAME}")

    model = SentenceTransformer(
        MODEL_NAME,
        device="cpu"
    )

    print("Embedding model loaded successfully.")

    # Prepare ChromaDB
    VECTOR_DB_DIR.mkdir(parents=True, exist_ok=True)

    client = chromadb.PersistentClient(
        path=str(VECTOR_DB_DIR)
    )

    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"}
    )

    all_ids = []
    all_documents = []
    all_metadatas = []

    # Read and split documents
    for file_path in files:
        text = file_path.read_text(encoding="utf-8-sig")

        chunks = split_text(text)

        category = "General"

        for line in text.splitlines():
            if line.strip().upper().startswith("CATEGORY:"):
                category = line.split(":", 1)[1].strip()
                break

        print(f"\nProcessing: {file_path.name}")
        print(f"Chunks created: {len(chunks)}")

        for index, chunk in enumerate(chunks):
            chunk_id = f"{file_path.stem}_{index:03d}"

            all_ids.append(chunk_id)
            all_documents.append(chunk)

            all_metadatas.append({
                "source": file_path.name,
                "category": category,
                "document_type": "demonstration_municipal_knowledge",
                "chunk_index": index,
                "disclaimer": (
                    "Academic demonstration guidance; "
                    "not an official government regulation."
                )
            })

    if not all_documents:
        raise ValueError("No document chunks were created.")

    # Generate embeddings locally
    print("\nGenerating local embeddings...")

    embeddings = model.encode(
        all_documents,
        convert_to_numpy=True,
        show_progress_bar=True
    )

    # Store or update documents in ChromaDB
    print("\nSaving knowledge to ChromaDB...")

    collection.upsert(
        ids=all_ids,
        documents=all_documents,
        metadatas=all_metadatas,
        embeddings=embeddings.tolist()
    )

    print("\n" + "=" * 45)
    print("RAG DOCUMENT INGESTION COMPLETED")
    print("=" * 45)
    print(f"Documents processed: {len(files)}")
    print(f"Text chunks stored: {len(all_documents)}")
    print(f"ChromaDB collection: {COLLECTION_NAME}")
    print(f"Vector database: {VECTOR_DB_DIR}")
    print(f"Total collection records: {collection.count()}")
    print("\nAll embeddings were generated locally.")


if __name__ == "__main__":
    main()
