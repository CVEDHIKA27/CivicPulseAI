
from backend.app.core.database import engine, Base
from backend.app.core.models import (
    User,
    Department,
    Complaint,
    ComplaintHistory,
    AIAnalysis
)


def create_tables():
    Base.metadata.create_all(bind=engine)
    print("CivicPulse AI database tables created successfully!")


if __name__ == "__main__":
    create_tables()
