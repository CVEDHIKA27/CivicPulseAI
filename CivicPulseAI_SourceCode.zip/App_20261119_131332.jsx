﻿
import { useEffect, useState } from "react";
import {
  ShieldCheck, Building2, Users, Mail, Lock, ArrowRight,
  MapPin, Activity, Eye, EyeOff, LogOut, PlusCircle,
  ClipboardList, RefreshCw, CheckCircle, Clock, AlertCircle,
  Send, BarChart3, Brain, FileText, AlertTriangle
} from "lucide-react";

import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Marker,
  Popup,
  useMap,
  useMapEvents
} from "react-leaflet";

import "leaflet/dist/leaflet.css";
import "./App.css";

const API = "http://127.0.0.1:8000";

/* --------------------------------------------------
   COMMON HELPERS
-------------------------------------------------- */

function getErrorMessage(detail, fallback = "Something went wrong.") {
  if (typeof detail === "string") return detail;

  if (Array.isArray(detail)) {
    return detail.map(item => item.msg || JSON.stringify(item)).join(", ");
  }

  if (detail && typeof detail === "object") {
    return detail.message || detail.msg || JSON.stringify(detail);
  }

  return fallback;
}

function normalizeStatus(value) {
  return String(value || "submitted")
    .toLowerCase()
    .replaceAll("-", "_")
    .replaceAll(" ", "_");
}

function normalizeUser(userData) {
  if (!userData || typeof userData !== "object") return null;

  return {
    ...userData,
    role: String(userData.role || "").trim().toLowerCase()
  };
}

/* --------------------------------------------------
   MAP PICKER COMPONENTS
-------------------------------------------------- */

function MapClickHandler({ onSelect }) {
  useMapEvents({
    click(event) {
      onSelect(event.latlng.lat, event.latlng.lng);
    }
  });

  return null;
}

function MapRecenter({ latitude, longitude }) {
  const map = useMap();

  useEffect(() => {
    if (latitude !== null && longitude !== null) {
      map.flyTo(
        [latitude, longitude],
        Math.max(map.getZoom(), 15),
        { duration: 1 }
      );
    }
  }, [map, latitude, longitude]);

  return null;
}

function ComplaintLocationPicker({
  latitude,
  longitude,
  setLatitude,
  setLongitude,
  setLocation
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState("");

  const selectedPosition =
    latitude !== null && longitude !== null
      ? [latitude, longitude]
      : null;

  function selectMapLocation(lat, lng) {
    setLatitude(lat);
    setLongitude(lng);
    setLocation(
      `Selected map location (${lat.toFixed(6)}, ${lng.toFixed(6)})`
    );
  }

  async function searchPlace(event) {
    event.preventDefault();

    if (searchQuery.trim().length < 3) {
      setSearchError("Enter at least 3 characters to search.");
      return;
    }

    setSearching(true);
    setSearchError("");
    setSearchResults([]);

    try {
      const url =
        "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=in&q=" +
        encodeURIComponent(searchQuery.trim());

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error("Location search is temporarily unavailable.");
      }

      const results = await response.json();

      setSearchResults(results);

      if (results.length === 0) {
        setSearchError("No matching places found. Try another search.");
      }
    } catch (error) {
      setSearchError(
        error.message || "Unable to search for this location."
      );
    } finally {
      setSearching(false);
    }
  }

  function chooseSearchResult(result) {
    const lat = Number(result.lat);
    const lng = Number(result.lon);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      setSearchError("Invalid coordinates returned for this location.");
      return;
    }

    setLatitude(lat);
    setLongitude(lng);
    setLocation(result.display_name);

    setSearchQuery(result.display_name);
    setSearchResults([]);
    setSearchError("");
  }

  function clearSelectedLocation() {
    setLatitude(null);
    setLongitude(null);
    setLocation("");
    setSearchQuery("");
    setSearchResults([]);
  }

  return (
    <div className="location-picker">
      <label>Search Complaint Location</label>

      <form onSubmit={searchPlace} className="location-search-form">
        <input
          type="text"
          value={searchQuery}
          onChange={event => setSearchQuery(event.target.value)}
          placeholder="Search street, area, town or landmark"
        />

        <button type="submit" disabled={searching}>
          {searching ? "Searching..." : "Search"}
        </button>
      </form>

      {searchResults.length > 0 && (
        <div className="location-search-results">
          {searchResults.map(result => (
            <button
              type="button"
              key={result.place_id}
              onClick={() => chooseSearchResult(result)}
            >
              {result.display_name}
            </button>
          ))}
        </div>
      )}

      {searchError && (
        <p className="location-search-error">{searchError}</p>
      )}

      <p className="location-picker-help">
        Search for a place or zoom into the map and click the exact location
        of the issue.
      </p>

      <MapContainer
        center={selectedPosition || [11.1271, 78.6569]}
        zoom={selectedPosition ? 15 : 7}
        minZoom={5}
        maxZoom={19}
        scrollWheelZoom={true}
        style={{
          height: "380px",
          width: "100%",
          borderRadius: "12px"
        }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapClickHandler onSelect={selectMapLocation} />

        <MapRecenter
          latitude={latitude}
          longitude={longitude}
        />

        {selectedPosition && (
          <Marker position={selectedPosition}>
            <Popup>
              Selected complaint location
              <br />
              Latitude: {latitude.toFixed(6)}
              <br />
              Longitude: {longitude.toFixed(6)}
            </Popup>
          </Marker>
        )}
      </MapContainer>

      <div className="selected-coordinates">
        {selectedPosition ? (
          <>
            <strong>Selected GPS Location</strong>
            <p>Latitude: {latitude.toFixed(6)}</p>
            <p>Longitude: {longitude.toFixed(6)}</p>

            <button
              type="button"
              className="text-button"
              onClick={clearSelectedLocation}
            >
              Clear selected location
            </button>
          </>
        ) : (
          <p>
            No GPS location selected yet. Search for a place or click the map.
          </p>
        )}
      </div>
    </div>
  );
}

/* --------------------------------------------------
   MAIN APPLICATION
-------------------------------------------------- */

function App() {
  const [user, setUser] = useState(() => {
    try {
      return normalizeUser(
        JSON.parse(localStorage.getItem("user"))
      );
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(
    localStorage.getItem("access_token") || ""
  );

  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const [page, setPage] = useState("dashboard");

  const [complaints, setComplaints] = useState([]);
  const [total, setTotal] = useState(0);
  const [loadingComplaints, setLoadingComplaints] = useState(false);

  const [adminComplaints, setAdminComplaints] = useState([]);
  const [loadingAdminComplaints, setLoadingAdminComplaints] = useState(false);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");

  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);

  const [latestAnalysis, setLatestAnalysis] = useState(null);

  const [updateId, setUpdateId] = useState("");
  const [newStatus, setNewStatus] = useState("under_review");
  const [remarks, setRemarks] = useState("");

  /* --------------------------------------------------
     API REQUEST HELPER
  -------------------------------------------------- */

  const request = async (path, options = {}) => {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        ...(options.headers || {}),
        ...(token
          ? { Authorization: `Bearer ${token}` }
          : {})
      }
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(
        getErrorMessage(
          data.detail,
          `Request failed (${response.status})`
        )
      );
    }

    return data;
  };

  /* --------------------------------------------------
     LOGIN AND REGISTRATION
  -------------------------------------------------- */

  const handleAuth = async event => {
    event.preventDefault();

    setError("");
    setMessage("");
    setLoading(true);

    try {
      const endpoint = isRegister
        ? "/auth/register"
        : "/auth/login";

      const body = isRegister
        ? { name: name.trim(), email: email.trim(), password }
        : { email: email.trim(), password };

      const response = await fetch(`${API}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          getErrorMessage(data.detail, "Authentication failed")
        );
      }

      if (isRegister) {
        setMessage("Registration successful. Please sign in.");
        setIsRegister(false);
        setPassword("");
        return;
      }

      if (!data.access_token || !data.user) {
        throw new Error(
          "Login response is missing the access token or user details."
        );
      }

      const normalizedUser = normalizeUser(data.user);

      if (!normalizedUser.role) {
        throw new Error(
          "Your account role is missing from the login response. Please contact the administrator."
        );
      }

      if (!["citizen", "officer", "admin"].includes(normalizedUser.role)) {
        throw new Error(
          `Unsupported account role: ${normalizedUser.role}`
        );
      }

      localStorage.setItem("access_token", data.access_token);
      localStorage.setItem("user", JSON.stringify(normalizedUser));

      setToken(data.access_token);
      setUser(normalizedUser);
      setPage("dashboard");
      setPassword("");
    } catch (err) {
      setError(err.message || "Unable to connect to the server.");
    } finally {
      setLoading(false);
    }
  };

  /* --------------------------------------------------
     LOAD CITIZEN COMPLAINTS
  -------------------------------------------------- */

  const loadComplaints = async () => {
    setLoadingComplaints(true);
    setError("");

    try {
      const data = await request("/complaints/my");

      setComplaints(data.complaints || []);
      setTotal(data.total_complaints || 0);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingComplaints(false);
    }
  };

  /* --------------------------------------------------
     LOAD OFFICER / ADMIN COMPLAINTS
  -------------------------------------------------- */

  const loadAdminComplaints = async () => {
    setLoadingAdminComplaints(true);
    setError("");

    try {
      const data = await request("/complaints/all");
      setAdminComplaints(data.complaints || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingAdminComplaints(false);
    }
  };

  useEffect(() => {
    if (!user || !token) return;

    if (user.role === "citizen") {
      loadComplaints();
    } else if (["officer", "admin"].includes(user.role)) {
      loadAdminComplaints();
    }
  }, [user, token]);

  /* --------------------------------------------------
     SUBMIT COMPLAINT
  -------------------------------------------------- */

  const submitComplaint = async event => {
    event.preventDefault();

    setError("");
    setMessage("");
    setLoading(true);
    setLatestAnalysis(null);

    try {
      const complaintPayload = {
        title: title.trim(),
        description: description.trim(),
        location: location.trim(),
        latitude,
        longitude
      };

      const data = await request("/complaints/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(complaintPayload)
      });

      setMessage(
        `Complaint ${data.complaint.complaint_number} submitted successfully!`
      );

      setLatestAnalysis(data.ai_analysis || null);

      setTitle("");
      setDescription("");
      setLocation("");
      setLatitude(null);
      setLongitude(null);

      await loadComplaints();
      setPage("dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  /* --------------------------------------------------
     UPDATE COMPLAINT STATUS
  -------------------------------------------------- */

  const updateStatus = async event => {
    event.preventDefault();

    setError("");
    setMessage("");
    setLoading(true);

    try {
      const data = await request(
        `/complaints/${updateId}/status`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            new_status: newStatus,
            remarks
          })
        }
      );

      setMessage(data.message || "Complaint status updated successfully.");
      setUpdateId("");
      setRemarks("");

      await loadAdminComplaints();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  /* --------------------------------------------------
     LOGOUT
  -------------------------------------------------- */

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("user");

    setToken("");
    setUser(null);

    setComplaints([]);
    setAdminComplaints([]);

    setPage("dashboard");
    setError("");
    setMessage("");
    setPassword("");
    setEmail("");
    setName("");
    setLatestAnalysis(null);
  };

  /* --------------------------------------------------
     CITIZEN ANALYTICS
  -------------------------------------------------- */

  const citizenResolved = complaints.filter(
    item => normalizeStatus(item.status) === "resolved"
  ).length;

  const citizenOpen = complaints.filter(
    item =>
      !["resolved", "rejected"].includes(
        normalizeStatus(item.status)
      )
  ).length;

  const citizenHighPriority = complaints.filter(
    item => String(item.priority || "").toLowerCase() === "high"
  ).length;

  /* --------------------------------------------------
     ADMIN / OFFICER ANALYTICS
  -------------------------------------------------- */

  const adminStatusCounts = {
    pending: adminComplaints.filter(item =>
      ["submitted", "under_review", "assigned"].includes(
        normalizeStatus(item.status)
      )
    ).length,

    inProgress: adminComplaints.filter(
      item => normalizeStatus(item.status) === "in_progress"
    ).length,

    resolved: adminComplaints.filter(
      item => normalizeStatus(item.status) === "resolved"
    ).length,

    rejected: adminComplaints.filter(
      item => normalizeStatus(item.status) === "rejected"
    ).length
  };

  const adminHighPriority = adminComplaints.filter(
    item => String(item.priority || "").toLowerCase() === "high"
  ).length;

  const departmentCounts = adminComplaints.reduce((result, item) => {
    const department = item.department || "Not assigned";
    result[department] = (result[department] || 0) + 1;
    return result;
  }, {});

  const departmentStats = Object.entries(departmentCounts)
    .sort((a, b) => b[1] - a[1]);

  const maxDepartmentCount = Math.max(
    1,
    ...departmentStats.map(([, count]) => count)
  );

  const adminTotal = adminComplaints.length;

  const resolutionRate = adminTotal
    ? Math.round((adminStatusCounts.resolved / adminTotal) * 100)
    : 0;

  /* --------------------------------------------------
     LOGIN PAGE
  -------------------------------------------------- */

  if (!user || !token) {
    return (
      <div className="app-container">
        <nav className="navbar">
          <div className="brand">
            <div className="brand-icon">
              <ShieldCheck size={27} />
            </div>

            <div>
              <h2>CivicPulse AI</h2>
              <span>SMART CITY • SMARTER GOVERNANCE</span>
            </div>
          </div>

          <div className="nav-status">
            <Activity size={17} />
            Intelligent Civic Platform
          </div>
        </nav>

        <main className="main-content">
          <section className="hero-section">
            <div className="hero-label">
              <span className="status-dot" />
              AI-POWERED PUBLIC SERVICE PLATFORM
            </div>

            <h1>
              Building Better Cities
              <br />
              Through <span>Intelligent Action.</span>
            </h1>

            <p className="hero-description">
              Report civic issues, connect with the right departments,
              and make our communities better through intelligent technology.
            </p>

            <div className="feature-list">
              <div className="feature-item">
                <div className="feature-icon">
                  <MapPin />
                </div>

                <div>
                  <h3>Smart Complaint Management</h3>
                  <p>Report and track civic complaints easily.</p>
                </div>
              </div>

              <div className="feature-item">
                <div className="feature-icon">
                  <Building2 />
                </div>

                <div>
                  <h3>Intelligent Department Routing</h3>
                  <p>Connect complaints to the right departments.</p>
                </div>
              </div>

              <div className="feature-item">
                <div className="feature-icon">
                  <Users />
                </div>

                <div>
                  <h3>Transparent Resolution Tracking</h3>
                  <p>Follow progress towards better public services.</p>
                </div>
              </div>
            </div>

            <div className="hero-footer">
              <ShieldCheck size={17} />
              Designed for transparent and accountable governance
            </div>

            {/* CITIZEN AND OFFICER INFORMATION */}

            <div className="user-types-section">
              <h3>One Platform. Two User Experiences.</h3>

              <div className="user-type-card">
                <div className="feature-icon">
                  <Users size={22} />
                </div>

                <div>
                  <h3>For Citizens</h3>
                  <p>
                    Report civic issues, submit complaints and track
                    their resolution progress.
                  </p>
                </div>
              </div>

              <div className="user-type-card">
                <div className="feature-icon">
                  <Building2 size={22} />
                </div>

                <div>
                  <h3>For Officers</h3>
                  <p>
                    Monitor complaints, manage department workload
                    and update resolution status.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section className="login-card">
            <div className="login-heading">
              <div className="login-icon">
                <ShieldCheck size={25} />
              </div>

              <h2>
                {isRegister ? "Create Account" : "Welcome Back"}
              </h2>

              <p>
                {isRegister
                  ? "Join CivicPulse AI today."
                  : "Sign in to access your dashboard."}
              </p>
            </div>

            {/* Role is determined by the backend, not selected here. */}

            <form onSubmit={handleAuth}>
              {isRegister && (
                <>
                  <label>Full Name</label>

                  <div className="input-wrapper">
                    <Users size={19} />

                    <input
                      value={name}
                      onChange={event => setName(event.target.value)}
                      placeholder="Enter your name"
                      required
                      minLength={2}
                    />
                  </div>
                </>
              )}

              <label>Email Address</label>

              <div className="input-wrapper">
                <Mail size={19} />

                <input
                  type="email"
                  value={email}
                  onChange={event => setEmail(event.target.value)}
                  placeholder="Enter your email"
                  required
                />
              </div>

              <label>Password</label>

              <div className="input-wrapper">
                <Lock size={19} />

                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={event => setPassword(event.target.value)}
                  placeholder="Enter your password"
                  required
                  minLength={8}
                />

                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword
                    ? <EyeOff size={19} />
                    : <Eye size={19} />}
                </button>
              </div>

              {error && (
                <p className="error-message">{error}</p>
              )}

              {message && (
                <p className="success-message">{message}</p>
              )}

              <button
                className="login-button"
                disabled={loading}
                type="submit"
              >
                {loading
                  ? "Please wait..."
                  : isRegister
                    ? "Create Account"
                    : "Sign In"}

                <ArrowRight size={19} />
              </button>
            </form>

            <p className="switch-auth">
              {isRegister
                ? "Already have an account?"
                : "New to CivicPulse AI?"}

              <button
                type="button"
                onClick={() => {
                  setIsRegister(!isRegister);
                  setError("");
                  setMessage("");
                }}
              >
                {isRegister ? " Sign in" : " Create account"}
              </button>
            </p>

            <div className="login-footer">
              <ShieldCheck size={16} />
              Secure access • Protected authentication
            </div>
          </section>
        </main>

        <footer className="app-footer">
          © 2026 CivicPulse AI. Building smarter communities together.
        </footer>
      </div>
    );
  }

  /* --------------------------------------------------
     DASHBOARD
  -------------------------------------------------- */

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <ShieldCheck size={30} />

          <div>
            <strong>CivicPulse AI</strong>
            <small>SMART GOVERNANCE</small>
          </div>
        </div>

        <div className="sidebar-user">
          <div className="avatar">
            {user.name?.charAt(0)?.toUpperCase() || "U"}
          </div>

          <div>
            <strong>{user.name}</strong>
            <small>{user.role}</small>
          </div>
        </div>

        <p className="menu-caption">WORKSPACE</p>

        <button
          className={page === "dashboard" ? "side-link selected" : "side-link"}
          onClick={() => {
            setPage("dashboard");

            if (user.role === "citizen") {
              loadComplaints();
            } else {
              loadAdminComplaints();
            }
          }}
        >
          <BarChart3 size={18} />
          Dashboard
        </button>

        {user.role === "citizen" ? (
          <>
            <button
              className={page === "new" ? "side-link selected" : "side-link"}
              onClick={() => {
                setPage("new");
                setError("");
                setMessage("");
              }}
            >
              <PlusCircle size={18} />
              Submit Complaint
            </button>

            <button
              className={page === "history" ? "side-link selected" : "side-link"}
              onClick={() => {
                setPage("history");
                loadComplaints();
              }}
            >
              <ClipboardList size={18} />
              My Complaints
            </button>
          </>
        ) : (
          <button
            className={page === "update" ? "side-link selected" : "side-link"}
            onClick={() => {
              setPage("update");
              setError("");
              setMessage("");
            }}
          >
            <RefreshCw size={18} />
            Update Status
          </button>
        )}

        <div className="sidebar-bottom">
          <button className="side-link logout-link" onClick={logout}>
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </aside>

      <main className="dashboard-main">
        <header className="dashboard-topbar">
          <div>
            <span className="eyebrow">CIVICPULSE WORKSPACE</span>

            <h1>
              {page === "new"
                ? "Submit a Complaint"
                : page === "history"
                  ? "My Complaints"
                  : page === "update"
                    ? "Update Complaint Status"
                    : "Dashboard"}
            </h1>
          </div>

          <div className="topbar-user">
            <span className="online-dot" />
            {user.name}
          </div>
        </header>

        {error && (
          <div className="alert error-alert">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        {message && (
          <div className="alert success-alert">
            <CheckCircle size={18} />
            {message}
          </div>
        )}

        {/* CITIZEN DASHBOARD */}

        {page === "dashboard" && user.role === "citizen" && (
          <>
            <section className="welcome-banner">
              <div>
                <span>WELCOME TO CIVICPULSE AI</span>
                <h2>Hello, {user.name}!</h2>
                <p>
                  Report issues in your community and track their resolution.
                </p>
              </div>

              <button
                className="banner-button"
                onClick={() => {
                  setPage("new");
                  setMessage("");
                }}
              >
                <PlusCircle size={18} />
                New Complaint
              </button>
            </section>

            <section className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon blue">
                  <ClipboardList />
                </div>
                <span>Total Complaints</span>
                <strong>{total}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon orange">
                  <Clock />
                </div>
                <span>Open Complaints</span>
                <strong>{citizenOpen}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon green">
                  <CheckCircle />
                </div>
                <span>Resolved</span>
                <strong>{citizenResolved}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon red">
                  <AlertTriangle />
                </div>
                <span>High Priority</span>
                <strong>{citizenHighPriority}</strong>
              </div>
            </section>

            <section className="panel">
              <div className="panel-heading">
                <div>
                  <h3>Recent Complaints</h3>
                  <p>Your latest submitted civic issues</p>
                </div>

                <button className="text-button" onClick={loadComplaints}>
                  <RefreshCw size={15} />
                  Refresh
                </button>
              </div>

              <ComplaintTable
                complaints={complaints.slice(0, 5)}
                loading={loadingComplaints}
                request={request}
              />
            </section>
          </>
        )}

        {/* OFFICER / ADMIN DASHBOARD */}

        {page === "dashboard" && ["officer", "admin"].includes(user.role) && (
          <>
            <section className="welcome-banner">
              <div>
                <span>SMART GOVERNANCE OVERVIEW</span>
                <h2>Welcome, {user.name}</h2>
                <p>
                  Monitor civic complaints, department workload and
                  resolution progress.
                </p>
              </div>

              <button
                className="banner-button"
                onClick={loadAdminComplaints}
                disabled={loadingAdminComplaints}
              >
                <RefreshCw size={17} />
                {loadingAdminComplaints ? "Refreshing..." : "Refresh Data"}
              </button>
            </section>

            <section className="stats-grid admin-stats-grid">
              <div className="stat-card">
                <div className="stat-icon blue">
                  <ClipboardList />
                </div>
                <span>Total Complaints</span>
                <strong>{adminTotal}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon orange">
                  <Clock />
                </div>
                <span>Pending</span>
                <strong>{adminStatusCounts.pending}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon blue">
                  <Activity />
                </div>
                <span>In Progress</span>
                <strong>{adminStatusCounts.inProgress}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon green">
                  <CheckCircle />
                </div>
                <span>Resolved</span>
                <strong>{adminStatusCounts.resolved}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon red">
                  <AlertTriangle />
                </div>
                <span>High Priority</span>
                <strong>{adminHighPriority}</strong>
              </div>
            </section>

            <section className="analytics-grid">
              <div className="panel analytics-panel">
                <div className="panel-heading">
                  <div>
                    <h3>Complaint Status Overview</h3>
                    <p>Distribution of all recorded complaints</p>
                  </div>

                  <Activity size={20} />
                </div>

                <div className="resolution-summary">
                  <div>
                    <strong>{resolutionRate}%</strong>
                    <span>Resolution rate</span>
                  </div>

                  <div className="resolution-track">
                    <div
                      className="resolution-fill"
                      style={{ width: `${resolutionRate}%` }}
                    />
                  </div>
                </div>

                <div className="status-chart">
                  {[
                    {
                      label: "Pending",
                      value: adminStatusCounts.pending,
                      color: "#e9a23b"
                    },
                    {
                      label: "In Progress",
                      value: adminStatusCounts.inProgress,
                      color: "#4389dc"
                    },
                    {
                      label: "Resolved",
                      value: adminStatusCounts.resolved,
                      color: "#29a36a"
                    },
                    {
                      label: "Rejected",
                      value: adminStatusCounts.rejected,
                      color: "#dc6262"
                    }
                  ].map(item => {
                    const percent = adminTotal
                      ? (item.value / adminTotal) * 100
                      : 0;

                    return (
                      <div className="status-chart-row" key={item.label}>
                        <div className="chart-label">
                          <span>
                            <i style={{ background: item.color }} />
                            {item.label}
                          </span>

                          <strong>{item.value}</strong>
                        </div>

                        <div className="chart-track">
                          <div
                            className="chart-fill"
                            style={{
                              width: `${percent}%`,
                              background: item.color
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="panel analytics-panel">
                <div className="panel-heading">
                  <div>
                    <h3>Department Workload</h3>
                    <p>Complaints assigned to each department</p>
                  </div>

                  <Building2 size={20} />
                </div>

                {departmentStats.length === 0 ? (
                  <p className="empty-state">
                    No department data available yet.
                  </p>
                ) : (
                  <div className="department-chart">
                    {departmentStats.map(([department, count]) => (
                      <div className="department-row" key={department}>
                        <div className="department-label">
                          <span title={department}>{department}</span>
                          <strong>{count}</strong>
                        </div>

                        <div className="chart-track">
                          <div
                            className="chart-fill department-fill"
                            style={{
                              width: `${(count / maxDepartmentCount) * 100}%`
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>

            <ComplaintMap complaints={adminComplaints} />

            <section className="panel">
              <div className="panel-heading">
                <div>
                  <h3>All Recent Complaints</h3>
                  <p>Latest complaints across the platform</p>
                </div>

                <button className="text-button" onClick={loadAdminComplaints}>
                  <RefreshCw size={15} />
                  Refresh
                </button>
              </div>

              <ComplaintTable
                complaints={adminComplaints.slice(0, 8)}
                loading={loadingAdminComplaints}
                request={request}
              />
            </section>
          </>
        )}

        {/* CITIZEN COMPLAINT SUBMISSION */}

        {page === "new" && user.role === "citizen" && (
          <section className="panel form-panel">
            <div className="panel-heading">
              <div>
                <h3>Report a Civic Issue</h3>
                <p>
                  Provide details so the AI agents can analyze and
                  route your complaint.
                </p>
              </div>
            </div>

            <form className="complaint-form" onSubmit={submitComplaint}>
              <label>Complaint Title</label>

              <input
                value={title}
                onChange={event => setTitle(event.target.value)}
                placeholder="Example: Water leakage near main road"
                required
                minLength={5}
                maxLength={200}
              />

              <label>Issue Description</label>

              <textarea
                value={description}
                onChange={event => setDescription(event.target.value)}
                placeholder="Describe the issue clearly..."
                required
                minLength={10}
                rows={5}
              />

              <label>Location Description</label>

              <input
                value={location}
                onChange={event => {
                  setLocation(event.target.value);
                  setLatitude(null);
                  setLongitude(null);
                }}
                placeholder="Street, area, city or landmark"
                required
                minLength={3}
                maxLength={255}
              />

              <ComplaintLocationPicker
                latitude={latitude}
                longitude={longitude}
                setLatitude={setLatitude}
                setLongitude={setLongitude}
                setLocation={setLocation}
              />

              <button
                className="login-button submit-button"
                disabled={loading}
                type="submit"
              >
                <Send size={18} />
                {loading ? "Analyzing and submitting..." : "Submit Complaint"}
              </button>
            </form>

            {latestAnalysis && (
              <div className="analysis-result">
                <h3>
                  <Activity size={19} />
                  AI Analysis Result
                </h3>

                <pre>{JSON.stringify(latestAnalysis, null, 2)}</pre>
              </div>
            )}
          </section>
        )}

        {/* CITIZEN COMPLAINT HISTORY */}

        {page === "history" && user.role === "citizen" && (
          <section className="panel">
            <div className="panel-heading">
              <div>
                <h3>Complaint History</h3>
                <p>Track the status of your submitted complaints.</p>
              </div>

              <button className="text-button" onClick={loadComplaints}>
                <RefreshCw size={15} />
                Refresh
              </button>
            </div>

            <ComplaintTable
              complaints={complaints}
              loading={loadingComplaints}
              request={request}
            />
          </section>
        )}

        {/* OFFICER / ADMIN STATUS UPDATE */}

        {page === "update" && ["officer", "admin"].includes(user.role) && (
          <section className="panel form-panel">
            <div className="panel-heading">
              <div>
                <h3>Update Complaint</h3>
                <p>
                  Enter the complaint database ID and update its
                  resolution status.
                </p>
              </div>
            </div>

            <form className="complaint-form" onSubmit={updateStatus}>
              <label>Complaint Database ID</label>

              <input
                type="number"
                min="1"
                value={updateId}
                onChange={event => setUpdateId(event.target.value)}
                placeholder="Example: 2"
                required
              />

              <label>New Status</label>

              <select
                value={newStatus}
                onChange={event => setNewStatus(event.target.value)}
              >
                <option value="under_review">Under Review</option>
                <option value="assigned">Assigned</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="rejected">Rejected</option>
              </select>

              <label>Remarks</label>

              <textarea
                value={remarks}
                onChange={event => setRemarks(event.target.value)}
                placeholder="Enter update remarks..."
                rows={4}
              />

              <button
                className="login-button submit-button"
                disabled={loading}
                type="submit"
              >
                <RefreshCw size={18} />
                {loading ? "Updating..." : "Update Status"}
              </button>
            </form>
          </section>
        )}

        {!["citizen", "officer", "admin"].includes(user.role) && (
          <section className="panel">
            <h3>Account role not recognized</h3>
            <p>
              Your account role is not supported. Please sign out and
              contact the administrator.
            </p>
            <button className="login-button" onClick={logout}>
              Sign Out
            </button>
          </section>
        )}
      </main>
    </div>
  );
}

/* --------------------------------------------------
   COMPLAINT MAP
-------------------------------------------------- */

const MAP_CITIES = [
  {
    key: "salem",
    name: "Salem",
    position: [11.6643, 78.1460]
  },
  {
    key: "tiruchengode",
    name: "Tiruchengode",
    position: [11.3802, 77.8944]
  },
  {
    key: "erode",
    name: "Erode",
    position: [11.3410, 77.7172]
  },
  {
    key: "chennai",
    name: "Chennai",
    position: [13.0827, 80.2707]
  },
  {
    key: "tiruchirappalli",
    name: "Tiruchirappalli",
    position: [10.7905, 78.7047]
  },
  {
    key: "trichy",
    name: "Tiruchirappalli",
    position: [10.7905, 78.7047]
  },
  {
    key: "tirchy",
    name: "Tiruchirappalli",
    position: [10.7905, 78.7047]
  },
  {
    key: "namakkal",
    name: "Namakkal",
    position: [11.2189, 78.1677]
  },
  {
    key: "coimbatore",
    name: "Coimbatore",
    position: [11.0168, 76.9558]
  }
];

function findComplaintCity(location) {
  const text = String(location || "").toLowerCase();

  return MAP_CITIES.find(city => text.includes(city.key));
}

function getMarkerColor(items) {
  const allResolved = items.every(
    item => normalizeStatus(item.status) === "resolved"
  );

  if (allResolved) return "#16a34a";

  const hasHighPriority = items.some(
    item => String(item.priority || "").toLowerCase() === "high"
  );

  if (hasHighPriority) return "#dc2626";

  return "#f59e0b";
}

function ComplaintMap({ complaints = [] }) {
  const hasGPS = item =>
    item.latitude !== null &&
    item.latitude !== undefined &&
    item.longitude !== null &&
    item.longitude !== undefined &&
    Number.isFinite(Number(item.latitude)) &&
    Number.isFinite(Number(item.longitude)) &&
    Number(item.latitude) >= -90 &&
    Number(item.latitude) <= 90 &&
    Number(item.longitude) >= -180 &&
    Number(item.longitude) <= 180;

  const exactLocationComplaints = complaints.filter(hasGPS);
  const complaintsWithoutGPS = complaints.filter(item => !hasGPS(item));

  const grouped = {};

  complaintsWithoutGPS.forEach(complaint => {
    const city = findComplaintCity(complaint.location);

    if (!city) return;

    if (!grouped[city.name]) {
      grouped[city.name] = {
        ...city,
        complaints: []
      };
    }

    grouped[city.name].complaints.push(complaint);
  });

  const cityGroups = Object.values(grouped);

  const unmappedCount = complaintsWithoutGPS.filter(
    complaint => !findComplaintCity(complaint.location)
  ).length;

  const mapCenter = exactLocationComplaints.length > 0
    ? [
        Number(exactLocationComplaints[0].latitude),
        Number(exactLocationComplaints[0].longitude)
      ]
    : [10.95, 78.35];

  return (
    <section className="panel geographic-map-panel">
      <div className="panel-heading">
        <div>
          <h3>Geographic Complaint Map</h3>
          <p>
            Exact GPS markers are shown where coordinates are available.
            Other complaints use approximate city centres.
          </p>
        </div>

        <span className="map-total">
          {complaints.length} complaints
        </span>
      </div>

      <div className="map-legend">
        <span>
          <i className="legend-dot map-red" />
          High priority / unresolved
        </span>

        <span>
          <i className="legend-dot map-amber" />
          Other unresolved
        </span>

        <span>
          <i className="legend-dot map-green" />
          All resolved
        </span>
      </div>

      {complaints.length > 0 ? (
        <MapContainer
          key={`${exactLocationComplaints.length}-${cityGroups.length}`}
          center={mapCenter}
          zoom={7}
          minZoom={5}
          maxZoom={19}
          scrollWheelZoom={true}
          className="complaint-leaflet-map"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxZoom={19}
          />

          {exactLocationComplaints.map(item => (
            <Marker
              key={`gps-${item.id}`}
              position={[
                Number(item.latitude),
                Number(item.longitude)
              ]}
            >
              <Popup>
                <div className="map-popup">
                  <strong>
                    {item.complaint_number || `Complaint #${item.id}`}
                  </strong>

                  <p>{item.title}</p>

                  <small>
                    Status: {item.status || "Unknown status"}
                  </small>

                  <br />

                  <small>
                    Priority: {item.priority || "Unavailable"}
                  </small>

                  <br />

                  <small>
                    {item.location || "Location unavailable"}
                  </small>

                  <br />

                  <small>
                    GPS: {Number(item.latitude).toFixed(6)},{" "}
                    {Number(item.longitude).toFixed(6)}
                  </small>
                </div>
              </Popup>
            </Marker>
          ))}

          {cityGroups.map(group => (
            <CircleMarker
              key={group.name}
              center={group.position}
              radius={Math.min(10 + group.complaints.length * 2, 22)}
              pathOptions={{
                color: getMarkerColor(group.complaints),
                fillColor: getMarkerColor(group.complaints),
                fillOpacity: 0.75,
                weight: 2
              }}
            >
              <Popup>
                <div className="map-popup">
                  <strong>{group.name}</strong>

                  <p>{group.complaints.length} complaint(s)</p>

                  {group.complaints.map(item => (
                    <div className="map-popup-item" key={item.id}>
                      <strong>
                        {item.complaint_number || `Complaint #${item.id}`}
                      </strong>

                      <div>{item.title}</div>

                      <small>
                        {item.status || "Unknown status"} •{" "}
                        {item.priority || "Priority unavailable"}
                      </small>

                      <div>
                        <small>
                          {item.location || "Location unavailable"}
                        </small>
                      </div>
                    </div>
                  ))}
                </div>
              </Popup>
            </CircleMarker>
          ))}
        </MapContainer>
      ) : (
        <p className="empty-state">
          No complaints are available to display yet.
        </p>
      )}

      <p className="map-disclaimer">
        GPS markers show the coordinates selected during complaint
        submission. City-centre markers are approximate locations.
      </p>

      {unmappedCount > 0 && (
        <p className="map-unmapped">
          {unmappedCount} complaint(s) have no GPS coordinates and
          locations not currently recognized by this map.
        </p>
      )}
    </section>
  );
}

/* --------------------------------------------------
   COMPLAINT TABLE
-------------------------------------------------- */

function ComplaintTable({ complaints, loading, request }) {
  if (loading) {
    return <p className="empty-state">Loading complaints...</p>;
  }

  if (!complaints.length) {
    return (
      <div className="empty-state">
        <ClipboardList size={35} />
        <strong>No complaints yet</strong>
        <span>Your submitted complaints will appear here.</span>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <table className="complaint-table">
        <thead>
          <tr>
            <th>Complaint</th>
            <th>Category</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Location</th>
            <th>AI Analysis</th>
            <th>Status Timeline</th>
          </tr>
        </thead>

        <tbody>
          {complaints.map(item => (
            <tr key={item.id}>
              <td>
                <strong>{item.title}</strong>
                <small>{item.complaint_number}</small>
              </td>

              <td>{item.category || "Pending"}</td>

              <td>
                <span
                  className={`priority ${
                    String(item.priority || "medium").toLowerCase()
                  }`}
                >
                  {item.priority || "Medium"}
                </span>
              </td>

              <td>
                <span
                  className={`status-pill ${
                    normalizeStatus(item.status).replaceAll("_", "-")
                  }`}
                >
                  {String(item.status || "submitted").replaceAll("_", " ")}
                </span>
              </td>

              <td>{item.location}</td>

              <td>
                <ComplaintAnalysis complaintId={item.id} request={request} />
              </td>

              <td>
                <ComplaintTimeline complaintId={item.id} request={request} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* --------------------------------------------------
   SAVED AI ANALYSIS
-------------------------------------------------- */

function ComplaintAnalysis({ complaintId, request }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);

  const loadAnalysis = async () => {
    if (loading || loaded) return;

    setLoading(true);
    setError("");

    try {
      const data = await request(`/complaints/${complaintId}/analysis`);
      setAnalysis(data);
      setLoaded(true);
    } catch (err) {
      setError(err.message || "Unable to load saved AI analysis.");
    } finally {
      setLoading(false);
    }
  };

  const records = Array.isArray(analysis?.ai_analysis)
    ? analysis.ai_analysis
    : [];

  const displayValue = value => {
    if (value === null || value === undefined) return "Not available";
    if (typeof value === "string") return value;
    return JSON.stringify(value, null, 2);
  };

  return (
    <div className="saved-ai-analysis">
      <details
        onToggle={event => {
          if (event.currentTarget.open) loadAnalysis();
        }}
      >
        <summary>
          <Brain size={16} />
          View Analysis
        </summary>

        <div className="saved-ai-content">
          {loading && (
            <p className="empty-state">Loading saved AI analysis...</p>
          )}

          {error && (
            <div className="error-message">
              <p>{error}</p>

              <button
                type="button"
                className="text-button"
                onClick={() => {
                  setLoaded(false);
                  setError("");
                  loadAnalysis();
                }}
              >
                <RefreshCw size={14} />
                Retry
              </button>
            </div>
          )}

          {loaded && (
            <>
              <h4>
                <Activity size={17} />
                Saved AI Analysis
              </h4>

              <p>
                Analysis records:{" "}
                <strong>{analysis?.total_agents ?? records.length}</strong>
              </p>

              {records.length === 0 && (
                <p className="empty-state">
                  No saved AI analysis records are available for this complaint.
                </p>
              )}

              {records.map((record, index) => (
                <div
                  className="ai-record-card"
                  key={`${record.agent_name || "agent"}-${index}`}
                >
                  <h5>
                    <Brain size={15} />
                    {record.agent_name || `Analysis Agent ${index + 1}`}
                  </h5>

                  {record.input_summary && (
                    <p>
                      <strong>Input:</strong> {record.input_summary}
                    </p>
                  )}

                  <p><strong>Output:</strong></p>

                  <pre>{displayValue(record.output_data)}</pre>

                  {record.confidence !== null &&
                    record.confidence !== undefined && (
                      <p>
                        <strong>Confidence:</strong>{" "}
                        {typeof record.confidence === "number"
                          ? `${(record.confidence * 100).toFixed(1)}%`
                          : displayValue(record.confidence)}
                      </p>
                    )}

                  {record.source_references && (
                    <div className="ai-sources">
                      <strong>
                        <FileText size={14} />
                        Knowledge Sources
                      </strong>

                      <pre>{displayValue(record.source_references)}</pre>
                    </div>
                  )}

                  {record.created_at && (
                    <small>
                      Saved: {new Date(record.created_at).toLocaleString()}
                    </small>
                  )}
                </div>
              ))}

              <p className="ai-review-note">
                <AlertCircle size={15} />
                AI recommendations are decision-support information.
                Department assignment and resolution require human oversight.
              </p>

              <p className="ai-disclaimer">
                Retrieved knowledge documents are academic demonstration
                materials and should not be treated as verified official
                municipal regulations.
              </p>
            </>
          )}
        </div>
      </details>
    </div>
  );
}

/* --------------------------------------------------
   COMPLAINT TIMELINE
-------------------------------------------------- */

function ComplaintTimeline({ complaintId, request }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);

  const loadTimeline = async () => {
    if (loading || loaded) return;

    setLoading(true);
    setError("");

    try {
      const result = await request(`/complaints/${complaintId}/timeline`);
      setData(result);
      setLoaded(true);
    } catch (err) {
      setError(err.message || "Unable to load complaint timeline.");
    } finally {
      setLoading(false);
    }
  };

  const formatDate = value => {
    if (!value) return "Date unavailable";

    const date = new Date(value);

    return Number.isNaN(date.getTime())
      ? "Date unavailable"
      : date.toLocaleString();
  };

  return (
    <div className="saved-ai-analysis">
      <details
        onToggle={event => {
          if (event.currentTarget.open) loadTimeline();
        }}
      >
        <summary>
          <Clock size={16} />
          View Timeline
        </summary>

        <div className="saved-ai-content">
          {loading && (
            <p className="empty-state">Loading complaint timeline...</p>
          )}

          {error && (
            <div className="error-message">
              <p>{error}</p>

              <button
                type="button"
                className="text-button"
                onClick={() => {
                  setLoaded(false);
                  setError("");
                  loadTimeline();
                }}
              >
                <RefreshCw size={14} />
                Retry
              </button>
            </div>
          )}

          {loaded && data && (
            <>
              <h4>
                <Activity size={17} />
                Complaint Status History
              </h4>

              <p>
                <strong>Complaint:</strong> {data.complaint_number}
              </p>

              <p>
                <strong>Current status:</strong>{" "}
                <span
                  className={`status-pill ${
                    normalizeStatus(data.current_status).replaceAll("_", "-")
                  }`}
                >
                  {String(data.current_status || "submitted").replaceAll("_", " ")}
                </span>
              </p>

              <p>
                <strong>Total updates:</strong> {data.total_updates}
              </p>

              {data.timeline?.length ? (
                <div className="complaint-timeline">
                  {data.timeline.map(event => (
                    <div
                      key={event.id}
                      className="ai-record-card"
                      style={{
                        marginBottom: "12px",
                        borderLeft: "3px solid #4389dc",
                        paddingLeft: "14px"
                      }}
                    >
                      <h5>
                        <Clock size={15} />
                        {String(event.status || "Unknown").replaceAll("_", " ")}
                      </h5>

                      <p>
                        <strong>Remarks:</strong>{" "}
                        {event.remarks || "No remarks provided"}
                      </p>

                      <p>
                        <strong>Updated by:</strong>{" "}
                        {event.updated_by || "System"}
                      </p>

                      <small>{formatDate(event.created_at)}</small>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="empty-state">
                  No timeline events are available.
                </p>
              )}
            </>
          )}
        </div>
      </details>
    </div>
  );
}

export default App;
