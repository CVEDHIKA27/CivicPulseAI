﻿
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.api.auth import router as auth_router
from backend.app.api.complaints import router as complaints_router


app = FastAPI(
    title="CivicPulse AI",
    description="Multi-Agent Urban Grievance Analysis and Resolution System",
    version="1.0.0"
)


# CORS configuration
app.add_middleware(
    CORSMiddleware,
   allow_origins=[
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5176",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5174",
    "http://127.0.0.1:5176"
],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register API routes
app.include_router(auth_router)
app.include_router(complaints_router)


# Serve uploaded complaint images
UPLOAD_DIRECTORY = (
    Path(__file__).resolve().parents[2]
    / "uploads"
)

UPLOAD_DIRECTORY.mkdir(parents=True, exist_ok=True)

app.mount(
    "/uploads",
    StaticFiles(directory=str(UPLOAD_DIRECTORY)),
    name="uploads"
)


@app.get("/")
def home():
    return {
        "project": "CivicPulse AI",
        "status": "Backend Running Successfully"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }
