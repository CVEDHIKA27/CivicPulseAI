
from datetime import datetime
from pathlib import Path
import secrets

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
    UploadFile,
    File
)
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.core.models import (
    Complaint,
    ComplaintHistory,
    User,
    Department,
    AIAnalysis
)
from backend.app.api.auth import get_current_user, require_role
from backend.app.agents.resolution_agent import track_resolution
from backend.app.agents.langgraph_workflow import process_complaint


router = APIRouter(
    prefix="/complaints",
    tags=["Complaint Management"]
)


# --------------------------------------------------
# REQUEST MODELS
# --------------------------------------------------

class ComplaintCreate(BaseModel):
    title: str = Field(min_length=5, max_length=200)
    description: str = Field(min_length=10)
    location: str = Field(min_length=3, max_length=255)

    # Optional GPS coordinates
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)


class ComplaintStatusUpdate(BaseModel):
    new_status: str
    remarks: str = Field(default="", max_length=1000)


# --------------------------------------------------
# CITIZEN SUBMITS A COMPLAINT
# --------------------------------------------------

@router.post("/", status_code=status.HTTP_201_CREATED)
def create_complaint(
    data: ComplaintCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "citizen":
        raise HTTPException(
            status_code=403,
            detail="Only citizens can submit complaints"
        )

    complaint_number = (
        "CP-"
        + datetime.now().strftime("%Y%m%d")
        + "-"
        + secrets.token_hex(4).upper()
    )

    complaint = Complaint(
        complaint_number=complaint_number,
        title=data.title.strip(),
        description=data.description.strip(),
        location=data.location.strip(),

        # Save selected map coordinates
        latitude=data.latitude,
        longitude=data.longitude,

        priority="medium",
        status="submitted",
        citizen_id=current_user.id
    )

    try:
        db.add(complaint)
        db.flush()

        # Execute four agents and RAG through LangGraph
        ai_result = process_complaint(
            description=complaint.description,
            location=complaint.location,
            complaint_id=complaint.complaint_number
        )

        understanding = ai_result["understanding_agent"]
        classification = ai_result["classification_agent"]
        routing = ai_result["routing_agent"]
        resolution = ai_result["resolution_agent"]
        rag_result = ai_result.get("rag_agent", {})

        # Update complaint classification
        complaint.category = classification["primary_category"]
        complaint.priority = classification["priority"]

        # Find or create department
        department_name = routing.get("department")

        if department_name:
            department = (
                db.query(Department)
                .filter(Department.name == department_name)
                .first()
            )

            if not department:
                department = Department(
                    name=department_name,
                    description=(
                        "Responsible for handling "
                        + department_name.lower()
                    )
                )
                db.add(department)
                db.flush()

            complaint.department_id = department.id

        # Save initial complaint history
        history = ComplaintHistory(
            complaint_id=complaint.id,
            status="submitted",
            remarks="Complaint submitted by citizen",
            updated_by=current_user.id
        )
        db.add(history)

        # Prepare four agent results
        agent_results = [
            (understanding["agent"], understanding),
            (classification["agent"], classification),
            (routing["agent"], routing),
            (resolution["agent"], resolution)
        ]

        # Prepare RAG result
        rag_output = {
            "status": rag_result.get("status", "unavailable"),
            "results_count": rag_result.get("results_count", 0),
            "retrieved_documents": rag_result.get(
                "retrieved_documents", []
            )
        }

        agent_results.append(
            ("RAG Knowledge Retrieval Agent", rag_output)
        )

        # Save all five analysis records
        for agent_name, output in agent_results:

            source_references = []

            if agent_name == "RAG Knowledge Retrieval Agent":
                source_references = sorted({
                    item.get("source", "Unknown")
                    for item in output.get(
                        "retrieved_documents", []
                    )
                })

            analysis_record = AIAnalysis(
                complaint_id=complaint.id,
                agent_name=agent_name,
                input_summary=complaint.description[:500],
                output_data=output,
                confidence=(
                    "semantic_search"
                    if agent_name == "RAG Knowledge Retrieval Agent"
                    else "not_calculated"
                ),
                source_references=source_references
            )

            db.add(analysis_record)

        # Commit complaint, history and five agent results
        db.commit()
        db.refresh(complaint)

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Unable to submit complaint or complete AI analysis"
        )

    return {
        "message": "Complaint submitted and AI analysis completed",
        "complaint": {
            "id": complaint.id,
            "complaint_number": complaint.complaint_number,
            "title": complaint.title,
            "description": complaint.description,
            "location": complaint.location,

            # Return GPS coordinates
            "latitude": complaint.latitude,
            "longitude": complaint.longitude,

            "category": complaint.category,
            "priority": complaint.priority,
            "status": complaint.status,
            "department_id": complaint.department_id,
            "citizen_id": complaint.citizen_id
        },
        "ai_analysis": ai_result
    }


# --------------------------------------------------
# CITIZEN VIEWS THEIR OWN COMPLAINTS
# --------------------------------------------------

@router.get("/my")
def get_my_complaints(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "citizen":
        raise HTTPException(
            status_code=403,
            detail="Only citizens can view their own complaints"
        )

    complaints = (
        db.query(Complaint)
        .filter(Complaint.citizen_id == current_user.id)
        .order_by(Complaint.created_at.desc())
        .all()
    )

    complaint_results = []

    for item in complaints:
        department = None

        if item.department_id:
            department = (
                db.query(Department)
                .filter(Department.id == item.department_id)
                .first()
            )

        complaint_results.append({
            "id": item.id,
            "complaint_number": item.complaint_number,
            "title": item.title,
            "description": item.description,
            "category": item.category,
            "priority": item.priority,
            "status": item.status,
            "location": item.location,

            # Return GPS coordinates
            "latitude": item.latitude,
            "longitude": item.longitude,

            "department": (
                department.name if department else "Not assigned"
            ),
            "department_id": item.department_id,
            "image_path": item.image_path,
            "created_at": (
                item.created_at.isoformat()
                if item.created_at else None
            )
        })

    return {
        "total_complaints": len(complaint_results),
        "complaints": complaint_results
    }


# --------------------------------------------------
# OFFICER AND ADMIN VIEW ALL COMPLAINTS
# --------------------------------------------------

@router.get("/all")
def get_all_complaints(
    current_user: User = Depends(
        require_role("officer", "admin")
    ),
    db: Session = Depends(get_db)
):
    complaints = (
        db.query(Complaint)
        .order_by(Complaint.created_at.desc())
        .all()
    )

    complaint_results = []

    for item in complaints:
        department = None

        if item.department_id:
            department = (
                db.query(Department)
                .filter(Department.id == item.department_id)
                .first()
            )

        complaint_results.append({
            "id": item.id,
            "complaint_number": item.complaint_number,
            "title": item.title,
            "description": item.description,
            "category": item.category,
            "priority": item.priority,
            "status": item.status,
            "location": item.location,

            # Return GPS coordinates
            "latitude": item.latitude,
            "longitude": item.longitude,

            "department": (
                department.name if department else "Not assigned"
            ),
            "department_id": item.department_id,
            "image_path": item.image_path,
            "created_at": (
                item.created_at.isoformat()
                if item.created_at else None
            )
        })

    return {
        "total_complaints": len(complaint_results),
        "complaints": complaint_results
    }


# --------------------------------------------------
# GET SAVED AI ANALYSIS FOR A COMPLAINT
# --------------------------------------------------

@router.get("/{complaint_id}/analysis")
def get_complaint_analysis(
    complaint_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    complaint = (
        db.query(Complaint)
        .filter(Complaint.id == complaint_id)
        .first()
    )

    if not complaint:
        raise HTTPException(
            status_code=404,
            detail="Complaint not found"
        )

    # Citizens can view only their own analysis
    if (
        current_user.role == "citizen"
        and complaint.citizen_id != current_user.id
    ):
        raise HTTPException(
            status_code=403,
            detail="You cannot view another citizen's AI analysis"
        )

    if current_user.role not in ("citizen", "officer", "admin"):
        raise HTTPException(
            status_code=403,
            detail="You are not authorized to view AI analysis"
        )

    records = (
        db.query(AIAnalysis)
        .filter(AIAnalysis.complaint_id == complaint.id)
        .order_by(AIAnalysis.id.asc())
        .all()
    )

    return {
        "complaint_id": complaint.complaint_number,
        "total_agents": len(records),
        "ai_analysis": [
            {
                "agent_name": record.agent_name,
                "input_summary": record.input_summary,
                "output_data": record.output_data,
                "confidence": record.confidence,
                "source_references": record.source_references,
                "created_at": (
                    record.created_at.isoformat()
                    if record.created_at else None
                )
            }
            for record in records
        ]
    }


# --------------------------------------------------
# OFFICER UPDATES COMPLAINT STATUS
# --------------------------------------------------

@router.patch("/{complaint_id}/status")
def update_complaint_status(
    complaint_id: int,
    data: ComplaintStatusUpdate,
    current_user: User = Depends(
        require_role("officer", "admin")
    ),
    db: Session = Depends(get_db)
):
    complaint = (
        db.query(Complaint)
        .filter(Complaint.id == complaint_id)
        .first()
    )

    if not complaint:
        raise HTTPException(
            status_code=404,
            detail="Complaint not found"
        )

    try:
        result = track_resolution(
            complaint_id=complaint.complaint_number,
            current_status=complaint.status,
            new_status=data.new_status,
            remarks=data.remarks
        )
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    try:
        complaint.status = data.new_status

        history = ComplaintHistory(
            complaint_id=complaint.id,
            status=data.new_status,
            remarks=data.remarks.strip(),
            updated_by=current_user.id
        )

        db.add(history)
        db.commit()
        db.refresh(complaint)

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Unable to update complaint status"
        )

    return {
        "message": "Complaint status updated successfully",
        "complaint_id": complaint.id,
        "complaint_number": complaint.complaint_number,
        "previous_status": result["previous_status"],
        "new_status": complaint.status,
        "updated_by": current_user.name,
        "remarks": data.remarks.strip()
    }


# --------------------------------------------------
# CITIZEN UPLOADS AN IMAGE FOR THEIR COMPLAINT
# --------------------------------------------------

@router.post("/{complaint_id}/image")
async def upload_complaint_image(
    complaint_id: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    allowed_types = {
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/webp": ".webp"
    }

    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Only JPG, PNG and WEBP images are allowed"
        )

    complaint = (
        db.query(Complaint)
        .filter(Complaint.id == complaint_id)
        .first()
    )

    if not complaint:
        raise HTTPException(
            status_code=404,
            detail="Complaint not found"
        )

    if (
        current_user.role == "citizen"
        and complaint.citizen_id != current_user.id
    ):
        raise HTTPException(
            status_code=403,
            detail="You cannot upload images to another citizen's complaint"
        )

    if current_user.role not in ("citizen", "officer", "admin"):
        raise HTTPException(
            status_code=403,
            detail="You are not authorized to upload images"
        )

    image_data = await file.read(5 * 1024 * 1024 + 1)

    if len(image_data) > 5 * 1024 * 1024:
        await file.close()
        raise HTTPException(
            status_code=413,
            detail="Image size must not exceed 5 MB"
        )

    extension = allowed_types[file.content_type]
    filename = secrets.token_hex(16) + extension

    upload_directory = (
        Path(__file__).resolve().parents[2]
        / "uploads"
        / "complaints"
    )

    upload_directory.mkdir(parents=True, exist_ok=True)

    image_path = upload_directory / filename

    try:
        image_path.write_bytes(image_data)

        complaint.image_path = f"complaints/{filename}"

        db.commit()
        db.refresh(complaint)

    except Exception:
        db.rollback()

        if image_path.exists():
            image_path.unlink()

        raise HTTPException(
            status_code=500,
            detail="Unable to save complaint image"
        )

    finally:
        await file.close()

    return {
        "message": "Complaint image uploaded successfully",
        "complaint_id": complaint.id,
        "image_path": f"/uploads/complaints/{filename}"
    }


# --------------------------------------------------
# COMPLAINT STATUS TIMELINE
# --------------------------------------------------

@router.get("/{complaint_id}/timeline")
def get_complaint_timeline(
    complaint_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Find complaint
    complaint = (
        db.query(Complaint)
        .filter(Complaint.id == complaint_id)
        .first()
    )

    if not complaint:
        raise HTTPException(
            status_code=404,
            detail="Complaint not found"
        )

    # Citizens can only view their own complaints
    if current_user.role == "citizen":
        if complaint.citizen_id != current_user.id:
            raise HTTPException(
                status_code=403,
                detail="You cannot view this complaint timeline"
            )
    elif current_user.role not in ("officer", "admin"):
        raise HTTPException(
            status_code=403,
            detail="Access denied"
        )

    # Retrieve actual history records
    history_records = (
        db.query(ComplaintHistory, User.name)
        .outerjoin(
            User,
            ComplaintHistory.updated_by == User.id
        )
        .filter(
            ComplaintHistory.complaint_id == complaint.id
        )
        .order_by(
            ComplaintHistory.created_at.asc(),
            ComplaintHistory.id.asc()
        )
        .all()
    )

    timeline = []

    for history, updater_name in history_records:
        timeline.append({
            "id": history.id,
            "status": history.status,
            "remarks": history.remarks,
            "updated_by": updater_name or "System",
            "created_at": (
                history.created_at.isoformat()
                if history.created_at else None
            )
        })

    return {
        "complaint_id": complaint.id,
        "complaint_number": complaint.complaint_number,
        "title": complaint.title,
        "current_status": complaint.status,
        "total_updates": len(timeline),
        "timeline": timeline
    }
