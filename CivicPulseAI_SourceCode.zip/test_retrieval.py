
from backend.app.agents.langgraph_workflow import process_complaint


def main():
    print("\nCIVICPULSE AI - COMPLETE LANGGRAPH + RAG TEST")
    print("=" * 60)

    result = process_complaint(
        description="There is continuous water leakage from a pipeline near the bus stand.",
        location="Bus Stand Road, Namakkal",
        complaint_id="RAG-TEST-001"
    )

    print("\n1. UNDERSTANDING AGENT")
    print(result["understanding_agent"])

    print("\n2. CLASSIFICATION AGENT")
    print(result["classification_agent"])

    print("\n3. RAG KNOWLEDGE RETRIEVAL")
    rag = result["rag_agent"]
    print("Status:", rag["status"])
    print("Documents retrieved:", rag["results_count"])

    for index, item in enumerate(
        rag["retrieved_documents"], start=1
    ):
        print(f"\nDocument {index}")
        print("Source:", item["source"])
        print("Category:", item["category"])
        print("Content:", item["content"][:250])
        print("Disclaimer:", item["disclaimer"])

    print("\n4. DEPARTMENT ROUTING AGENT")
    print(result["routing_agent"])

    print("\n5. RESOLUTION TRACKING AGENT")
    print(result["resolution_agent"])

    print("\nOVERALL STATUS:", result["overall_status"])
    print("Human review required:", result["requires_human_review"])

    print("\n" + "=" * 60)
    print("COMPLETE WORKFLOW TEST FINISHED")


if __name__ == "__main__":
    main()
