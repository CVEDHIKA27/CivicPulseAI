
from typing import Any, TypedDict

from langgraph.graph import StateGraph, START, END

from backend.app.agents.understanding_agent import understand_complaint
from backend.app.agents.classification_agent import classify_complaint
from backend.app.agents.routing_agent import route_complaint
from backend.app.agents.resolution_agent import track_resolution

from backend.app.rag.retriever import retrieve_knowledge


class ComplaintState(TypedDict):
    description: str
    location: str
    complaint_id: str
    understanding: dict[str, Any] | None
    classification: dict[str, Any] | None
    rag_context: list[dict[str, Any]] | None
    routing: dict[str, Any] | None
    resolution: dict[str, Any] | None


# Agent 1: Understand the complaint
def understanding_node(state: ComplaintState) -> dict:
    result = understand_complaint(
        state["description"],
        state["location"]
    )
    return {"understanding": result}


# Agent 2: Classify the complaint
def classification_node(state: ComplaintState) -> dict:
    result = classify_complaint(
        state["description"],
        state["understanding"]["detected_topics"]
    )
    return {"classification": result}


# RAG Node: Retrieve relevant municipal knowledge
def rag_node(state: ComplaintState) -> dict:
    detected_topics = state["understanding"]["detected_topics"]

    search_query = (
        state["description"]
        + " "
        + " ".join(str(topic) for topic in detected_topics)
    )

    knowledge = retrieve_knowledge(
        query=search_query,
        top_k=3
    )

    return {"rag_context": knowledge}


# Agent 3: Route to the responsible department
def routing_node(state: ComplaintState) -> dict:
    result = route_complaint(state["classification"])
    return {"routing": result}


# Agent 4: Initialize resolution tracking
def resolution_node(state: ComplaintState) -> dict:
    result = track_resolution(
        state["complaint_id"],
        current_status="submitted"
    )
    return {"resolution": result}


# Build the LangGraph workflow
builder = StateGraph(ComplaintState)

builder.add_node("understanding", understanding_node)
builder.add_node("classification", classification_node)
builder.add_node("rag_retrieval", rag_node)
builder.add_node("routing", routing_node)
builder.add_node("resolution", resolution_node)

builder.add_edge(START, "understanding")
builder.add_edge("understanding", "classification")
builder.add_edge("classification", "rag_retrieval")
builder.add_edge("rag_retrieval", "routing")
builder.add_edge("routing", "resolution")
builder.add_edge("resolution", END)

complaint_graph = builder.compile()


def process_complaint(
    description: str,
    location: str,
    complaint_id: str
) -> dict:

    initial_state: ComplaintState = {
        "description": description,
        "location": location,
        "complaint_id": complaint_id,
        "understanding": None,
        "classification": None,
        "rag_context": None,
        "routing": None,
        "resolution": None
    }

    result = complaint_graph.invoke(initial_state)

    understanding = result["understanding"]
    classification = result["classification"]
    rag_context = result["rag_context"]
    routing = result["routing"]
    resolution = result["resolution"]

    return {
        "project": "CivicPulse AI",
        "complaint_id": complaint_id,
        "understanding_agent": understanding,
        "classification_agent": classification,
        "rag_agent": {
            "status": "retrieval_completed",
            "retrieved_documents": rag_context,
            "results_count": len(rag_context)
        },
        "routing_agent": routing,
        "resolution_agent": resolution,
        "overall_status": "analysis_completed",
        "requires_human_review": (
            understanding["requires_review"]
            or classification["requires_review"]
            or routing["requires_human_approval"]
        )
    }
