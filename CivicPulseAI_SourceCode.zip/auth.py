
import os
import json
import hmac
import hashlib
import base64
import secrets

from datetime import datetime, timedelta, timezone
from typing import Callable

from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status
)
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.core.models import User


load_dotenv()

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)

SECRET_KEY = os.getenv("AUTH_SECRET_KEY")

if not SECRET_KEY or SECRET_KEY == "development-secret-change-before-deployment":
    raise RuntimeError(
        "Set a secure AUTH_SECRET_KEY in your .env file"
    )

TOKEN_EXPIRY_HOURS = 24

bearer_scheme = HTTPBearer(auto_error=False)


# -----------------------------
# REQUEST SCHEMAS
# -----------------------------

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# -----------------------------
# PASSWORD HASHING
# -----------------------------

def hash_password(password: str) -> str:

    salt = secrets.token_bytes(16)

    hashed = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        310000
    )

    return (
        base64.b64encode(salt).decode()
        + "$"
        + base64.b64encode(hashed).decode()
    )


def verify_password(password: str, stored_hash: str) -> bool:

    try:
        salt_text, hash_text = stored_hash.split("$")

        salt = base64.b64decode(salt_text)
        expected_hash = base64.b64decode(hash_text)

        actual_hash = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            310000
        )

        return hmac.compare_digest(
            actual_hash,
            expected_hash
        )

    except (ValueError, TypeError):
        return False


# -----------------------------
# JWT TOKEN GENERATION
# -----------------------------

def encode_base64(data: bytes) -> str:

    return base64.urlsafe_b64encode(
        data
    ).rstrip(b"=").decode("utf-8")


def decode_base64(data: str) -> bytes:

    padding = "=" * (-len(data) % 4)

    return base64.urlsafe_b64decode(
        data + padding
    )


def create_access_token(user_id: int, role: str) -> str:

    now = datetime.now(timezone.utc)

    header = {
        "alg": "HS256",
        "typ": "JWT"
    }

    payload = {
        "sub": str(user_id),
        "role": role,
        "iat": int(now.timestamp()),
        "exp": int(
            (now + timedelta(hours=TOKEN_EXPIRY_HOURS))
            .timestamp()
        )
    }

    header_part = encode_base64(
        json.dumps(header, separators=(",", ":")).encode()
    )

    payload_part = encode_base64(
        json.dumps(payload, separators=(",", ":")).encode()
    )

    message = f"{header_part}.{payload_part}"

    signature = hmac.new(
        SECRET_KEY.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256
    ).digest()

    signature_part = encode_base64(signature)

    return f"{message}.{signature_part}"


# -----------------------------
# JWT TOKEN VERIFICATION
# -----------------------------

def verify_access_token(token: str) -> dict:

    try:
        parts = token.split(".")

        if len(parts) != 3:
            raise ValueError("Invalid token format")

        header_part, payload_part, signature_part = parts

        message = f"{header_part}.{payload_part}"

        expected_signature = hmac.new(
            SECRET_KEY.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256
        ).digest()

        actual_signature = decode_base64(signature_part)

        if not hmac.compare_digest(
            expected_signature,
            actual_signature
        ):
            raise ValueError("Invalid signature")

        header = json.loads(
            decode_base64(header_part)
        )

        payload = json.loads(
            decode_base64(payload_part)
        )

        if header.get("alg") != "HS256":
            raise ValueError("Unsupported algorithm")

        if not payload.get("sub"):
            raise ValueError("Missing user ID")

        if not isinstance(payload.get("exp"), int):
            raise ValueError("Invalid expiration")

        if not isinstance(payload.get("iat"), int):
            raise ValueError("Invalid issue time")

        now = int(datetime.now(timezone.utc).timestamp())

        if payload["exp"] <= now:
            raise ValueError("Token expired")

        if payload["iat"] > now + 60:
            raise ValueError("Invalid token issue time")

        return payload

    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired access token",
            headers={"WWW-Authenticate": "Bearer"}
        )


# -----------------------------
# CURRENT USER AUTHENTICATION
# -----------------------------

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(
        bearer_scheme
    ),
    db: Session = Depends(get_db)
):

    if credentials is None:
        raise HTTPException(
            status_code=401,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"}
        )

    if credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication scheme"
        )

    payload = verify_access_token(credentials.credentials)

    try:
        user_id = int(payload["sub"])
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=401,
            detail="Invalid user information in token"
        )

    user = db.query(User).filter(
        User.id == user_id
    ).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="User no longer exists"
        )

    # Always use the current database role.
    # Do not trust an old role stored in a token.
    if user.role not in ["citizen", "officer", "admin"]:
        raise HTTPException(
            status_code=403,
            detail="Invalid user role"
        )

    return user


# -----------------------------
# ROLE-BASED AUTHORIZATION
# -----------------------------

def require_role(*allowed_roles: str) -> Callable:

    def role_checker(
        current_user: User = Depends(get_current_user)
    ):

        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=403,
                detail="You do not have permission to access this resource"
            )

        return current_user

    return role_checker


# -----------------------------
# CITIZEN REGISTRATION
# -----------------------------

@router.post("/register")
def register(
    data: RegisterRequest,
    db: Session = Depends(get_db)
):

    existing_user = db.query(User).filter(
        User.email == data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=409,
            detail="Email already registered"
        )

    user = User(
        name=data.name,
        email=data.email,
        hashed_password=hash_password(data.password),
        role="citizen"
    )

    try:
        db.add(user)
        db.commit()
        db.refresh(user)

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Unable to register citizen"
        )

    return {
        "message": "Citizen registered successfully",
        "user_id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role
    }


# -----------------------------
# LOGIN
# -----------------------------

@router.post("/login")
def login(
    data: LoginRequest,
    db: Session = Depends(get_db)
):

    user = db.query(User).filter(
        User.email == data.email
    ).first()

    if not user or not verify_password(
        data.password,
        user.hashed_password
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    token = create_access_token(
        user.id,
        user.role
    )

    return {
        "message": "Login successful",
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role
        }
    }


# -----------------------------
# CURRENT USER PROFILE
# -----------------------------

@router.get("/me")
def get_my_profile(
    current_user: User = Depends(get_current_user)
):

    return {
        "message": "Authenticated successfully",
        "user": {
            "id": current_user.id,
            "name": current_user.name,
            "email": current_user.email,
            "role": current_user.role
        }
    }


# -----------------------------
# CITIZEN PROTECTED TEST API
# -----------------------------

@router.get("/citizen-check")
def citizen_check(
    current_user: User = Depends(
        require_role("citizen")
    )
):

    return {
        "message": "Citizen access verified",
        "user": current_user.name,
        "role": current_user.role
    }


# -----------------------------
# OFFICER PROTECTED TEST API
# -----------------------------

@router.get("/officer-check")
def officer_check(
    current_user: User = Depends(
        require_role("officer", "admin")
    )
):

    return {
        "message": "Officer access verified",
        "user": current_user.name,
        "role": current_user.role
    }