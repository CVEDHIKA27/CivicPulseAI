﻿
import json
import os
import re

from dotenv import load_dotenv
from openai import OpenAI
from google import genai

load_dotenv()

ALLOWED_TOPICS = {
    "water",
    "road",
    "waste",
    "electricity",
    "drainage"
}


def _normalize_text(text: str) -> str:
    """Normalize complaint text."""
    return re.sub(r"\s+", " ", text.strip())


def _extract_json(response_text: str) -> dict:
    """Extract and validate JSON from AI response."""

    if not response_text:
        raise ValueError("AI returned an empty response.")

    cleaned = response_text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    result = json.loads(cleaned)

    if not isinstance(result, dict):
        raise ValueError("AI response must be a JSON object.")

    return result


def _clean_topics(topics: list, description: str) -> list:
    """Validate AI topics against actual complaint evidence."""

    text = description.lower()

    evidence_patterns = {
        "water": [
            r"\bwater\b",
            r"\bpipeline\b",
            r"\bleakage\b",
            r"\bwater supply\b",
            r"\bdrinking water\b"
        ],

        "road": [
            r"\bpothole\b",
            r"\broad damage\b",
            r"\bdamaged road\b",
            r"\bbroken road\b",
            r"\bcracked road\b",
            r"\bstreet damage\b",
            r"\bdamaged street\b",
            r"\bdamaged pavement\b",
            r"\bbroken pavement\b",
            r"\broad surface\b",
            r"\btraffic congestion\b"
        ],

        "waste": [
            r"\bgarbage\b",
            r"\brubbish\b",
            r"\btrash\b",
            r"\blitter\b",
            r"\bdustbins?\b",
            r"\bsolid waste\b",
            r"\bwaste collection\b",
            r"\bgarbage collection\b",
            r"\bwaste disposal\b",
            r"\bplastic waste\b",
            r"\bfood waste\b",
            r"\buncollected waste\b"
        ],

        "electricity": [
            r"\belectricity\b",
            r"\bpower cut\b",
            r"\bpower outage\b",
            r"\bstreet light\b",
            r"\belectric pole\b",
            r"\bpower supply\b",
            r"\bexposed wires\b",
            r"\bpower failure\b"
        ],

        "drainage": [
            r"\bdrainage\b",
            r"\bsewage\b",
            r"\bblocked drain\b",
            r"\bdrain blockage\b",
            r"\bsewage overflow\b",
            r"\bstagnant wastewater\b"
        ]
    }

    cleaned_topics = []

    for topic in topics:
        if not isinstance(topic, str):
            continue

        topic = topic.strip().lower()

        if topic not in ALLOWED_TOPICS:
            continue

        patterns = evidence_patterns.get(topic, [])

        if any(re.search(pattern, text) for pattern in patterns):
            if topic not in cleaned_topics:
                cleaned_topics.append(topic)

    return cleaned_topics


def _local_understanding(
    description: str,
    location: str = ""
) -> dict:
    """Local keyword-based fallback."""

    normalized_text = _normalize_text(description)
    text = normalized_text.lower()

    topic_patterns = {
        "water": [
            r"\bwater\b",
            r"\bpipeline\b",
            r"\bleakage\b",
            r"\bdrinking water\b",
            r"\bwater supply\b"
        ],

        "road": [
            r"\bpothole\b",
            r"\broad damage\b",
            r"\bdamaged road\b",
            r"\bbroken road\b",
            r"\bcracked road\b",
            r"\bstreet damage\b",
            r"\bdamaged street\b",
            r"\bdamaged pavement\b",
            r"\bbroken pavement\b",
            r"\btraffic congestion\b"
        ],

        "waste": [
            r"\bgarbage\b",
            r"\brubbish\b",
            r"\btrash\b",
            r"\blitter\b",
            r"\bdustbins?\b",
            r"\bsolid waste\b",
            r"\bwaste collection\b",
            r"\bgarbage collection\b",
            r"\bwaste disposal\b",
            r"\bplastic waste\b",
            r"\bfood waste\b",
            r"\buncollected waste\b"
        ],

        "electricity": [
            r"\belectricity\b",
            r"\bpower cut\b",
            r"\bpower outage\b",
            r"\bstreet light\b",
            r"\belectric pole\b",
            r"\bpower supply\b",
            r"\bexposed wires\b",
            r"\bpower failure\b"
        ],

        "drainage": [
            r"\bdrainage\b",
            r"\bsewage\b",
            r"\bblocked drain\b",
            r"\bdrain blockage\b",
            r"\bsewage overflow\b",
            r"\bstagnant wastewater\b"
        ]
    }

    detected_topics = []

    for category, patterns in topic_patterns.items():
        if any(re.search(pattern, text) for pattern in patterns):
            detected_topics.append(category)

    detected_topics = _clean_topics(
        detected_topics,
        normalized_text
    )

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": normalized_text,
        "location": location.strip(),
        "detected_topics": detected_topics,
        "summary": normalized_text[:200],
        "status": "understood",
        "method": "local_keyword_fallback",
        "requires_review": True
    }


def _build_result(
    description: str,
    location: str,
    result: dict,
    method: str
) -> dict:
    """Build a validated and consistent agent response."""

    topics = result.get("detected_topics", [])

    if not isinstance(topics, list):
        raise ValueError("Invalid detected_topics returned by AI.")

    topics = _clean_topics(topics, description)

    summary = result.get("summary", description[:200])

    if not isinstance(summary, str):
        summary = description[:200]

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": description,
        "location": location.strip(),
        "detected_topics": topics,
        "summary": summary.strip()[:500],
        "status": "understood",
        "method": method,
        "requires_review": (
            bool(result.get("requires_review", True))
            or not topics
        )
    }


def _get_prompt(description: str, location: str) -> str:
    """Create the complaint understanding prompt."""

    return f"""
You are the Complaint Understanding Agent for CivicPulse AI.

Analyze this municipal complaint.

Complaint: {description}
Location: {location}

Allowed categories:
water, road, waste, electricity, drainage.

Classification rules:

1. Select categories based on the actual problem,
   not merely words appearing in the location.

2. Water leakage, damaged pipelines and drinking
   water problems belong to water.

3. The phrase "water is being wasted" is a water
   complaint, NOT a solid-waste complaint.

4. Waste means garbage, rubbish, litter, dustbins,
   solid waste collection or waste disposal.

5. The phrase "Main Road" as a location does not
   mean the complaint belongs to road.

6. Road means actual potholes, damaged roads,
   broken pavements or road-related problems.

7. Power cuts, damaged electric poles and exposed
   wires belong to electricity.

8. Blocked drains and sewage problems belong
   to drainage.

9. Do not invent facts or locations.

10. If unclear, set requires_review to true.

Return ONLY valid JSON:

{{
    "summary": "Short complaint summary",
    "detected_topics": ["water"],
    "requires_review": true
}}
"""


def _understand_with_nexus(
    description: str,
    location: str
) -> dict:
    """Use Nexus as the primary AI provider."""

    api_key = os.getenv("NEXUS_API_KEY")

    if not api_key:
        raise ValueError("NEXUS_API_KEY is not configured.")

    client = OpenAI(
        api_key=api_key,
        base_url=os.getenv(
            "NEXUS_BASE_URL",
            "https://nexusapi.navigatelabs.ai"
        )
    )

    response = client.chat.completions.create(
        model=os.getenv("NEXUS_MODEL", "nova-micro"),
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a careful civic complaint "
                    "analysis AI. Return only valid JSON."
                )
            },
            {
                "role": "user",
                "content": _get_prompt(description, location)
            }
        ],
        temperature=0.1
    )

    content = response.choices[0].message.content
    result = _extract_json(content)

    return _build_result(
        description,
        location,
        result,
        "nexus_ai"
    )


def _understand_with_gemini(
    description: str,
    location: str
) -> dict:
    """Use Gemini when Nexus is unavailable."""

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise ValueError("GEMINI_API_KEY is not configured.")

    client = genai.Client(api_key=api_key)

    response = client.models.generate_content(
        model="gemini-3.5-flash-lite",
        contents=_get_prompt(description, location)
    )

    result = _extract_json(response.text)

    return _build_result(
        description,
        location,
        result,
        "gemini_ai"
    )


def understand_complaint(
    description: str,
    location: str = ""
) -> dict:
    """
    Understand a civic complaint.

    Provider priority:
    1. Nexus AI
    2. Gemini AI
    3. Local keyword fallback
    """

    if not description or not description.strip():
        raise ValueError(
            "Complaint description cannot be empty."
        )

    normalized_text = _normalize_text(description)

    # Primary provider: Nexus
    try:
        return _understand_with_nexus(
            normalized_text,
            location
        )

    except Exception as nexus_error:
        print(
            "Nexus understanding failed:",
            str(nexus_error)
        )

    # Secondary provider: Gemini
    try:
        return _understand_with_gemini(
            normalized_text,
            location
        )

    except Exception as gemini_error:
        print(
            "Gemini understanding failed:",
            str(gemini_error)
        )

    # Final fallback: local keyword detection
    return _local_understanding(
        normalized_text,
        location
    )
