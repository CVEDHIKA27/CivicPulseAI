
from backend.app.core.database import SessionLocal
from backend.app.core.models import AIAnalysis


def main():
    db = SessionLocal()

    try:
        records = (
            db.query(AIAnalysis)
            .filter(
                AIAnalysis.agent_name
                == "RAG Knowledge Retrieval Agent"
            )
            .order_by(AIAnalysis.id.desc())
            .limit(5)
            .all()
        )

        print("\nCIVICPULSE AI - RAG DATABASE CHECK")
        print("=" * 50)
        print("RAG records found:", len(records))

        for record in records:
            print("\nRecord ID:", record.id)
            print("Complaint ID:", record.complaint_id)
            print("Agent:", record.agent_name)
            print("Sources:", record.source_references)
            print("Output:", record.output_data)

        if not records:
            print("\nNo RAG records stored yet.")
            print("Submit a new complaint to test RAG storage.")

    finally:
        db.close()


if __name__ == "__main__":
    main()
