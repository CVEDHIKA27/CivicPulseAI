
import secrets
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.core.models import (
    Complaint,
    ComplaintHistory,
    User,
    Department,
    AIAnalysis
)
from backend.app.api.auth import get_current_user, require_role
from backend.app.agents.resolution_agent import track_resolution
from backend.app.agents.workflow import process_complaint


router = APIRouter(
    prefix="/complaints",
    tags=["Complaint Management"]
)


# Complaint submission request
class ComplaintCreate(BaseModel):
    title: str = Field(min_length=5, max_length=200)
    description: str = Field(min_length=10)
    location: str = Field(min_length=3, max_length=255)


# Officer status update request
class ComplaintStatusUpdate(BaseModel):
    new_status: str
    remarks: str = Field(default="", max_length=1000)


# Citizen submits a new complaint
@router.post("/", status_code=status.HTTP_201_CREATED)
def create_complaint(
    data: ComplaintCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "citizen":
        raise HTTPException(
            status_code=403,
            detail="Only citizens can submit complaints"
        )

    complaint_number = (
        "CP-"
        + datetime.now().strftime("%Y%m%d")
        + "-"
        + secrets.token_hex(4).upper()
    )

    complaint = Complaint(
        complaint_number=complaint_number,
        title=data.title.strip(),
        description=data.description.strip(),
        location=data.location.strip(),
        priority="medium",
        status="submitted",
        citizen_id=current_user.id
    )

    try:
        db.add(complaint)
        db.flush()

        # Run the four local AI agent prototypes
        ai_result = process_complaint(
            description=complaint.description,
            location=complaint.location,
            complaint_id=complaint.complaint_number
        )

        understanding = ai_result["understanding_agent"]
        classification = ai_result["classification_agent"]
        routing = ai_result["routing_agent"]
        resolution = ai_result["resolution_agent"]

        # Update complaint with classification results
        complaint.category = classification["primary_category"]
        complaint.priority = classification["priority"]

        # Find or create the recommended department
        department_name = routing.get("department")

        if department_name:
            department = (
                db.query(Department)
                .filter(Department.name == department_name)
                .first()
            )

            if not department:
                department = Department(
                    name=department_name,
                    description=(
                        "Responsible for handling "
                        + department_name.lower()
                    )
                )
                db.add(department)
                db.flush()

            complaint.department_id = department.id

        # Save initial complaint history
        history = ComplaintHistory(
            complaint_id=complaint.id,
            status="submitted",
            remarks="Complaint submitted by citizen",
            updated_by=current_user.id
        )
        db.add(history)

        # Save the output of each agent
        agent_results = [
            (understanding["agent"], understanding),
            (classification["agent"], classification),
            (routing["agent"], routing),
            (resolution["agent"], resolution)
        ]

        for agent_name, output in agent_results:
            analysis_record = AIAnalysis(
                complaint_id=complaint.id,
                agent_name=agent_name,
                input_summary=complaint.description[:500],
                output_data=output,
                confidence="rule_based",
                source_references=[]
            )
            db.add(analysis_record)

        db.commit()
        db.refresh(complaint)

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Unable to submit complaint or complete AI analysis"
        )

    return {
        "message": "Complaint submitted and AI analysis completed",
        "complaint": {
            "id": complaint.id,
            "complaint_number": complaint.complaint_number,
            "title": complaint.title,
            "description": complaint.description,
            "location": complaint.location,
            "category": complaint.category,
            "priority": complaint.priority,
            "status": complaint.status,
            "department_id": complaint.department_id,
            "citizen_id": complaint.citizen_id
        },
        "ai_analysis": ai_result
    }


# Citizen views their own complaints
@router.get("/my")
def get_my_complaints(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    complaints = (
        db.query(Complaint)
        .filter(Complaint.citizen_id == current_user.id)
        .order_by(Complaint.created_at.desc())
        .all()
    )

    return {
        "total_complaints": len(complaints),
        "complaints": [
            {
                "id": item.id,
                "complaint_number": item.complaint_number,
                "title": item.title,
                "category": item.category,
                "priority": item.priority,
                "status": item.status,
                "location": item.location
            }
            for item in complaints
        ]
    }


# Officer updates complaint status
@router.patch("/{complaint_id}/status")
def update_complaint_status(
    complaint_id: int,
    data: ComplaintStatusUpdate,
    current_user: User = Depends(
        require_role("officer", "admin")
    ),
    db: Session = Depends(get_db)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == complaint_id
    ).first()

    if not complaint:
        raise HTTPException(
            status_code=404,
            detail="Complaint not found"
        )

    try:
        result = track_resolution(
            complaint_id=complaint.complaint_number,
            current_status=complaint.status,
            new_status=data.new_status,
            remarks=data.remarks
        )
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    try:
        complaint.status = data.new_status

        history = ComplaintHistory(
            complaint_id=complaint.id,
            status=data.new_status,
            remarks=data.remarks.strip(),
            updated_by=current_user.id
        )

        db.add(history)
        db.commit()
        db.refresh(complaint)

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Unable to update complaint status"
        )

    return {
        "message": "Complaint status updated successfully",
        "complaint_id": complaint.id,
        "complaint_number": complaint.complaint_number,
        "previous_status": result["previous_status"],
        "new_status": complaint.status,
        "updated_by": current_user.name,
        "remarks": data.remarks.strip()
    }
