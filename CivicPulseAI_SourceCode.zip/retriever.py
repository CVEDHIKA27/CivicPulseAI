
from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = Path(__file__).resolve().parents[3]

VECTOR_DB_DIR = PROJECT_ROOT / "data" / "chroma_db"

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

COLLECTION_NAME = "civicpulse_municipal_knowledge"

# Load the model and database only once per Python process.
_model = None
_collection = None


def get_model():
    global _model

    if _model is None:
        _model = SentenceTransformer(
            MODEL_NAME,
            device="cpu"
        )

    return _model


def get_collection():
    global _collection

    if _collection is None:
        if not VECTOR_DB_DIR.exists():
            raise FileNotFoundError(
                "ChromaDB folder not found. Run the ingestion script first."
            )

        client = chromadb.PersistentClient(
            path=str(VECTOR_DB_DIR)
        )

        _collection = client.get_collection(
            name=COLLECTION_NAME
        )

    return _collection


def retrieve_knowledge(
    query: str,
    top_k: int = 3
) -> list[dict]:
    """
    Retrieve relevant municipal demonstration guidance
    for a citizen complaint.
    """

    if not query or not query.strip():
        raise ValueError("Search query cannot be empty.")

    if top_k < 1:
        raise ValueError("top_k must be at least 1.")

    model = get_model()
    collection = get_collection()

    query_embedding = model.encode(
        [query.strip()],
        convert_to_numpy=True
    )

    result = collection.query(
        query_embeddings=query_embedding.tolist(),
        n_results=min(top_k, collection.count()),
        include=["documents", "metadatas", "distances"]
    )

    retrieved_items = []

    documents = result.get("documents", [[]])[0]
    metadatas = result.get("metadatas", [[]])[0]
    distances = result.get("distances", [[]])[0]

    for document, metadata, distance in zip(
        documents,
        metadatas,
        distances
    ):
        retrieved_items.append({
            "content": document,
            "source": metadata.get("source", "Unknown"),
            "category": metadata.get("category", "General"),
            "distance": round(float(distance), 4),
            "disclaimer": metadata.get("disclaimer", "")
        })

    return retrieved_items
