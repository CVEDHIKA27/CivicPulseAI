
import json
import os
import re

from dotenv import load_dotenv
from google import genai
from openai import OpenAI

load_dotenv()

DEPARTMENT_MAPPING = {
    "water": "Water Supply Department",
    "road": "Roads and Public Works Department",
    "waste": "Sanitation Department",
    "electricity": "Electricity Department",
    "drainage": "Drainage Department"
}

ALLOWED_PRIORITIES = {"high", "medium"}


def _local_classification(description: str, detected_topics=None) -> dict:
    """Fallback classification using local rules."""

    text = description.lower()
    topics = detected_topics or []

    matched_categories = [
        topic.lower()
        for topic in topics
        if isinstance(topic, str)
        and topic.lower() in DEPARTMENT_MAPPING
    ]

    if not matched_categories:
        matched_categories = [
            category
            for category in DEPARTMENT_MAPPING
            if category in text
        ]

    matched_categories = list(dict.fromkeys(matched_categories))

    primary_category = (
        matched_categories[0] if matched_categories else "unknown"
    )

    priority_keywords = [
        "emergency", "danger", "accident", "fire",
        "overflow", "exposed wire", "severe", "unsafe"
    ]

    priority = (
        "high"
        if any(word in text for word in priority_keywords)
        else "medium"
    )

    return {
        "agent": "Complaint Classification Agent",
        "primary_category": primary_category,
        "matched_categories": matched_categories,
        "responsible_department": DEPARTMENT_MAPPING.get(
            primary_category,
            "Manual Department Review Required"
        ),
        "priority": priority,
        "method": "local_rule_based_fallback",
        "requires_review": len(matched_categories) != 1
    }


def _extract_json(response_text: str) -> dict:
    """Parse JSON returned by an AI provider."""

    if not response_text:
        raise ValueError("AI provider returned an empty response.")

    cleaned = response_text.strip()
    cleaned = re.sub(
        r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE
    )
    cleaned = re.sub(r"\s*```$", "", cleaned)

    result = json.loads(cleaned)

    if not isinstance(result, dict):
        raise ValueError("AI response must be a JSON object.")

    return result


def _build_classification(result: dict, method: str) -> dict:
    """Validate and standardize AI classification output."""

    allowed_categories = set(DEPARTMENT_MAPPING.keys())

    primary_category = result.get("primary_category", "unknown")

    if not isinstance(primary_category, str):
        primary_category = "unknown"

    primary_category = primary_category.lower()

    if primary_category not in allowed_categories:
        primary_category = "unknown"

    categories = result.get("matched_categories", [])

    if not isinstance(categories, list):
        raise ValueError("Invalid matched categories.")

    matched_categories = list(dict.fromkeys(
        category.lower()
        for category in categories
        if isinstance(category, str)
        and category.lower() in allowed_categories
    ))

    if (
        primary_category != "unknown"
        and primary_category not in matched_categories
    ):
        matched_categories.insert(0, primary_category)

    if primary_category == "unknown" and matched_categories:
        primary_category = matched_categories[0]

    priority = result.get("priority", "medium")

    if not isinstance(priority, str):
        priority = "medium"

    priority = priority.lower()

    if priority not in ALLOWED_PRIORITIES:
        priority = "medium"

    return {
        "agent": "Complaint Classification Agent",
        "primary_category": primary_category,
        "matched_categories": matched_categories,
        "responsible_department": DEPARTMENT_MAPPING.get(
            primary_category,
            "Manual Department Review Required"
        ),
        "priority": priority,
        "method": method,
        "requires_review": (
            bool(result.get("requires_review", True))
            or primary_category == "unknown"
            or len(matched_categories) != 1
        )
    }


def classify_complaint(description: str, detected_topics=None) -> dict:
    """Classify a municipal complaint using Nexus, Gemini, or local rules."""

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    prompt = f"""
You are the Complaint Classification Agent for CivicPulse AI.

Classify this municipal complaint.

Complaint: {description}
Topics identified by the Understanding Agent: {detected_topics}

Allowed categories:
water, road, waste, electricity, drainage

Allowed priorities:
high, medium

Rules:
- Select one primary category.
- Include only clearly relevant categories in matched_categories.
- Do not infer unrelated categories from location words.
- Use high priority for emergencies, danger, accidents,
  exposed electrical wires, serious flooding or safety risks.
- Otherwise use medium priority.
- Do not invent facts.

Return ONLY valid JSON in this format:
{{
  "primary_category": "water",
  "matched_categories": ["water"],
  "priority": "medium",
  "requires_review": false
}}
"""

    # 1. Try Nexus first.
    nexus_key = os.getenv("NEXUS_API_KEY")
    nexus_base_url = os.getenv("NEXUS_BASE_URL")
    nexus_model = os.getenv("NEXUS_MODEL", "nova-micro")

    if nexus_key and nexus_base_url and nexus_model:
        try:
            client = OpenAI(
                api_key=nexus_key,
                base_url=nexus_base_url,
                timeout=30.0
            )

            response = client.chat.completions.create(
                model=nexus_model,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            result = _extract_json(
                response.choices[0].message.content
            )

            return _build_classification(result, "nexus_ai")

        except Exception as error:
            print(
                "Nexus classification unavailable:",
                type(error).__name__
            )

    # 2. Try Gemini if Nexus is unavailable.
    gemini_key = os.getenv("GEMINI_API_KEY")

    if gemini_key:
        try:
            client = genai.Client(api_key=gemini_key)

            response = client.models.generate_content(
                model="gemini-3.5-flash-lite",
                contents=prompt
            )

            result = _extract_json(response.text)

            return _build_classification(result, "gemini_ai")

        except Exception as error:
            print(
                "Gemini classification unavailable:",
                type(error).__name__
            )

    # 3. Final local fallback.
    return _local_classification(description, detected_topics)
