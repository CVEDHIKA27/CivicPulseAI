
def classify_complaint(description: str, detected_topics=None) -> dict:
    """
    Local Complaint Classification Agent.
    Classifies complaints and estimates priority.
    """

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    text = description.lower()

    department_mapping = {
        "water": "Water Supply Department",
        "road": "Roads and Public Works Department",
        "waste": "Sanitation Department",
        "electricity": "Electricity Department",
        "drainage": "Drainage Department"
    }

    topics = detected_topics or []

    matched_categories = [
        topic for topic in topics
        if topic in department_mapping
    ]

    if not matched_categories:
        for topic, department in department_mapping.items():
            if topic in text:
                matched_categories.append(topic)

    primary_category = (
        matched_categories[0] if matched_categories else "unknown"
    )

    priority_keywords = [
        "emergency", "danger", "accident", "fire",
        "overflow", "exposed wire", "severe"
    ]

    priority = (
        "high" if any(word in text for word in priority_keywords)
        else "medium"
    )

    return {
        "agent": "Complaint Classification Agent",
        "primary_category": primary_category,
        "matched_categories": matched_categories,
        "responsible_department": department_mapping.get(
            primary_category, "Manual Department Review Required"
        ),
        "priority": priority,
        "method": "local_rule_based_classification",
        "requires_review": len(matched_categories) != 1
    }
