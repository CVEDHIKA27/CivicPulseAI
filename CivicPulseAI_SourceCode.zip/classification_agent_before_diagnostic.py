
import json
import os

from dotenv import load_dotenv
from google import genai

load_dotenv()

DEPARTMENT_MAPPING = {
    "water": "Water Supply Department",
    "road": "Roads and Public Works Department",
    "waste": "Sanitation Department",
    "electricity": "Electricity Department",
    "drainage": "Drainage Department"
}


def _local_classification(description: str, detected_topics=None) -> dict:
    """Fallback classification using local rules."""

    text = description.lower()
    topics = detected_topics or []

    matched_categories = [
        topic.lower()
        for topic in topics
        if isinstance(topic, str) and topic.lower() in DEPARTMENT_MAPPING
    ]

    if not matched_categories:
        matched_categories = [
            category
            for category in DEPARTMENT_MAPPING
            if category in text
        ]

    matched_categories = list(dict.fromkeys(matched_categories))

    primary_category = (
        matched_categories[0] if matched_categories else "unknown"
    )

    priority_keywords = [
        "emergency", "danger", "accident", "fire",
        "overflow", "exposed wire", "severe", "unsafe"
    ]

    priority = (
        "high"
        if any(word in text for word in priority_keywords)
        else "medium"
    )

    return {
        "agent": "Complaint Classification Agent",
        "primary_category": primary_category,
        "matched_categories": matched_categories,
        "responsible_department": DEPARTMENT_MAPPING.get(
            primary_category,
            "Manual Department Review Required"
        ),
        "priority": priority,
        "method": "local_rule_based_fallback",
        "requires_review": len(matched_categories) != 1
    }


def classify_complaint(description: str, detected_topics=None) -> dict:
    """Classify a municipal complaint using Gemini with local fallback."""

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        return _local_classification(description, detected_topics)

    try:
        client = genai.Client(api_key=api_key)

        prompt = f"""
You are the Complaint Classification Agent for CivicPulse AI.

Classify this municipal complaint.

Complaint: {description}
Topics identified by the Understanding Agent: {detected_topics}

Allowed categories:
water, road, waste, electricity, drainage

Allowed priorities:
high, medium

Rules:
- Select one primary category.
- Include all relevant categories in matched_categories.
- Use high priority for emergencies, danger, accidents,
  exposed electrical wires, serious flooding or safety risks.
- Otherwise use medium priority.
- Do not invent facts.

Return ONLY valid JSON in this format:
{{
  "primary_category": "water",
  "matched_categories": ["water"],
  "priority": "medium",
  "requires_review": false
}}
"""

        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt
        )

        if not response.text:
            raise ValueError("Gemini returned an empty response.")

        result = json.loads(response.text)

        allowed_categories = set(DEPARTMENT_MAPPING.keys())

        primary_category = result.get("primary_category", "unknown")
        if not isinstance(primary_category, str):
            raise ValueError("Invalid primary category.")

        primary_category = primary_category.lower()

        if primary_category not in allowed_categories:
            primary_category = "unknown"

        categories = result.get("matched_categories", [])

        if not isinstance(categories, list):
            raise ValueError("Invalid matched categories.")

        matched_categories = list(dict.fromkeys(
            category.lower()
            for category in categories
            if isinstance(category, str)
            and category.lower() in allowed_categories
        ))

        if primary_category != "unknown" and primary_category not in matched_categories:
            matched_categories.insert(0, primary_category)

        if primary_category == "unknown" and matched_categories:
            primary_category = matched_categories[0]

        priority = result.get("priority", "medium")
        if not isinstance(priority, str):
            priority = "medium"

        priority = priority.lower()
        if priority not in {"high", "medium"}:
            priority = "medium"

        return {
            "agent": "Complaint Classification Agent",
            "primary_category": primary_category,
            "matched_categories": matched_categories,
            "responsible_department": DEPARTMENT_MAPPING.get(
                primary_category,
                "Manual Department Review Required"
            ),
            "priority": priority,
            "method": "gemini_ai",
            "requires_review": (
                bool(result.get("requires_review", True))
                or primary_category == "unknown"
                or len(matched_categories) != 1
            )
        }
    except Exception as error:
        print(f"Classification Gemini unavailable: {type(error).__name__}")
        return _local_classification(description, detected_topics)