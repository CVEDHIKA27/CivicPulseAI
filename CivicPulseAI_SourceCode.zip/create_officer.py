﻿from getpass import getpass
from backend.app.core.database import SessionLocal
from backend.app.core.models import User
from backend.app.api.auth import hash_password

name = input("Officer name: ").strip()
email = input("Officer email: ").strip().lower()
password = getpass("Create officer password: ")
confirm = getpass("Confirm officer password: ")

if len(name) < 2:
    print("ERROR: Invalid name.")
elif len(password) < 8:
    print("ERROR: Password must have at least 8 characters.")
elif password != confirm:
    print("ERROR: Passwords do not match.")
else:
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == email).first()

        if existing:
            print("ERROR: Email already exists.")
        else:
            officer = User(
                name=name,
                email=email,
                hashed_password=hash_password(password),
                role="officer"
            )
            db.add(officer)
            db.commit()
            db.refresh(officer)

            print("OFFICER ACCOUNT CREATED SUCCESSFULLY")
            print("User ID:", officer.id)
            print("Name:", officer.name)
            print("Email:", officer.email)
            print("Role:", officer.role)
    except Exception as error:
        db.rollback()
        print("ERROR:", error)
    finally:
        db.close()
