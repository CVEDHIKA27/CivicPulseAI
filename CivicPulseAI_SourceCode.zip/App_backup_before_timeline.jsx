import { useEffect, useState } from "react";
import {
  ShieldCheck, Building2, Users, Mail, Lock, ArrowRight,
  MapPin, Activity, Eye, EyeOff, LogOut, PlusCircle,
  ClipboardList, RefreshCw, CheckCircle, Clock, AlertCircle,
  Send, BarChart3, Brain, FileText, TrendingUp, AlertTriangle
} from "lucide-react";
import "./App.css";

const API = "http://127.0.0.1:8000";

function getErrorMessage(detail, fallback = "Something went wrong.") {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail.map(item => item.msg || JSON.stringify(item)).join(", ");
  }
  if (detail && typeof detail === "object") {
    return detail.message || detail.msg || JSON.stringify(detail);
  }
  return fallback;
}

function normalizeStatus(status) {
  return String(status || "submitted").toLowerCase().replaceAll("-", "_").replaceAll(" ", "_");
}

function App() {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("user")) || null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(
    localStorage.getItem("access_token") || ""
  );

  const [role, setRole] = useState("citizen");
  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const [page, setPage] = useState("dashboard");
  const [complaints, setComplaints] = useState([]);
  const [total, setTotal] = useState(0);
  const [loadingComplaints, setLoadingComplaints] = useState(false);

  // Separate data store for officer/admin complaints.
  const [adminComplaints, setAdminComplaints] = useState([]);
  const [loadingAdminComplaints, setLoadingAdminComplaints] = useState(false);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [latestAnalysis, setLatestAnalysis] = useState(null);

  const [updateId, setUpdateId] = useState("");
  const [newStatus, setNewStatus] = useState("under_review");
  const [remarks, setRemarks] = useState("");

  const request = async (path, options = {}) => {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        ...(options.headers || {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(
        getErrorMessage(data.detail, `Request failed (${response.status})`)
      );
    }

    return data;
  };

  const handleAuth = async (event) => {
    event.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const endpoint = isRegister ? "/auth/register" : "/auth/login";
      const body = isRegister
        ? { name, email, password }
        : { email, password };

      const response = await fetch(`${API}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          getErrorMessage(data.detail, "Authentication failed")
        );
      }

      if (isRegister) {
        setMessage("Registration successful. Please sign in.");
        setIsRegister(false);
        setPassword("");
        return;
      }

      if (data.user?.role !== role) {
        throw new Error(
          `This account has the role "${data.user?.role}". Please select the correct role.`
        );
      }

      localStorage.setItem("access_token", data.access_token);
      localStorage.setItem("user", JSON.stringify(data.user));

      setToken(data.access_token);
      setUser(data.user);
      setPage("dashboard");
    } catch (err) {
      setError(err.message || "Unable to connect to the server.");
    } finally {
      setLoading(false);
    }
  };

  const loadComplaints = async () => {
    setLoadingComplaints(true);
    setError("");

    try {
      const data = await request("/complaints/my");
      setComplaints(data.complaints || []);
      setTotal(data.total_complaints || 0);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingComplaints(false);
    }
  };

  const loadAdminComplaints = async () => {
    setLoadingAdminComplaints(true);
    setError("");

    try {
      const data = await request("/complaints/all");
      setAdminComplaints(data.complaints || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingAdminComplaints(false);
    }
  };

  useEffect(() => {
    if (!user || !token) return;

    if (user.role === "citizen") {
      loadComplaints();
    } else if (["officer", "admin"].includes(user.role)) {
      loadAdminComplaints();
    }
  }, [user, token]);

  const submitComplaint = async (event) => {
    event.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);
    setLatestAnalysis(null);

    try {
      const data = await request("/complaints/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, location }),
      });

      setMessage(
        `Complaint ${data.complaint.complaint_number} submitted successfully!`
      );

      setLatestAnalysis(data.ai_analysis);
      setTitle("");
      setDescription("");
      setLocation("");

      await loadComplaints();
      setPage("dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (event) => {
    event.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const data = await request(`/complaints/${updateId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          new_status: newStatus,
          remarks,
        }),
      });

      setMessage(data.message);
      setUpdateId("");
      setRemarks("");

      if (user?.role === "citizen") {
        await loadComplaints();
      } else {
        await loadAdminComplaints();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("user");
    setToken("");
    setUser(null);
    setComplaints([]);
    setAdminComplaints([]);
    setPage("dashboard");
    setError("");
    setMessage("");
  };

  // Citizen analytics are calculated only from that citizen's own complaints.
  const citizenResolved = complaints.filter(
    item => normalizeStatus(item.status) === "resolved"
  ).length;
  const citizenOpen = complaints.filter(
    item => !["resolved", "rejected"].includes(normalizeStatus(item.status))
  ).length;
  const citizenHighPriority = complaints.filter(
    item => String(item.priority || "").toLowerCase() === "high"
  ).length;

  // Admin/officer analytics use the authorized /complaints/all response.
  const adminStatusCounts = {
    pending: adminComplaints.filter(item =>
      ["submitted", "under_review", "assigned"].includes(normalizeStatus(item.status))
    ).length,
    inProgress: adminComplaints.filter(
      item => normalizeStatus(item.status) === "in_progress"
    ).length,
    resolved: adminComplaints.filter(
      item => normalizeStatus(item.status) === "resolved"
    ).length,
    rejected: adminComplaints.filter(
      item => normalizeStatus(item.status) === "rejected"
    ).length,
  };

  const adminHighPriority = adminComplaints.filter(
    item => String(item.priority || "").toLowerCase() === "high"
  ).length;

  const departmentCounts = adminComplaints.reduce((result, item) => {
    const department = item.department || "Not assigned";
    result[department] = (result[department] || 0) + 1;
    return result;
  }, {});

  const departmentStats = Object.entries(departmentCounts)
    .sort((a, b) => b[1] - a[1]);

  const maxDepartmentCount = Math.max(
    1,
    ...departmentStats.map(([, count]) => count)
  );

  const adminTotal = adminComplaints.length;
  const resolutionRate = adminTotal
    ? Math.round((adminStatusCounts.resolved / adminTotal) * 100)
    : 0;

  if (!user || !token) {
    return (
      <div className="app-container">
        <nav className="navbar">
          <div className="brand">
            <div className="brand-icon"><ShieldCheck size={27} /></div>
            <div>
              <h2>CivicPulse AI</h2>
              <span>SMART CITY • SMARTER GOVERNANCE</span>
            </div>
          </div>
          <div className="nav-status">
            <Activity size={17} /> Intelligent Civic Platform
          </div>
        </nav>

        <main className="main-content">
          <section className="hero-section">
            <div className="hero-label">
              <span className="status-dot" />
              AI-POWERED PUBLIC SERVICE PLATFORM
            </div>

            <h1>
              Building Better Cities<br />
              Through <span>Intelligent Action.</span>
            </h1>

            <p className="hero-description">
              Report civic issues, connect with the right departments,
              and make our communities better through intelligent technology.
            </p>

            <div className="feature-list">
              <div className="feature-item">
                <div className="feature-icon"><MapPin /></div>
                <div>
                  <h3>Smart Complaint Management</h3>
                  <p>Report and track civic complaints easily.</p>
                </div>
              </div>

              <div className="feature-item">
                <div className="feature-icon"><Building2 /></div>
                <div>
                  <h3>Intelligent Department Routing</h3>
                  <p>Connect complaints to the right departments.</p>
                </div>
              </div>

              <div className="feature-item">
                <div className="feature-icon"><Users /></div>
                <div>
                  <h3>Transparent Resolution Tracking</h3>
                  <p>Follow progress towards better public services.</p>
                </div>
              </div>
            </div>

            <div className="hero-footer">
              <ShieldCheck size={17} />
              Designed for transparent and accountable governance
            </div>
          </section>

          <section className="login-card">
            <div className="login-heading">
              <div className="login-icon"><ShieldCheck size={25} /></div>
              <h2>{isRegister ? "Create Account" : "Welcome Back"}</h2>
              <p>
                {isRegister
                  ? "Join CivicPulse AI today."
                  : "Sign in to access your dashboard."}
              </p>
            </div>

            {!isRegister && (
              <div className="role-selector">
                <button
                  type="button"
                  className={`role-option ${role === "citizen" ? "active" : ""}`}
                  onClick={() => setRole("citizen")}
                >
                  <Users size={18} /> Citizen
                </button>

                <button
                  type="button"
                  className={`role-option ${role === "officer" ? "active" : ""}`}
                  onClick={() => setRole("officer")}
                >
                  <Building2 size={18} /> Officer
                </button>
              </div>
            )}

            <form onSubmit={handleAuth}>
              {isRegister && (
                <>
                  <label>Full Name</label>
                  <div className="input-wrapper">
                    <Users size={19} />
                    <input
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="Enter your name"
                      required
                      minLength={2}
                    />
                  </div>
                </>
              )}

              <label>Email Address</label>
              <div className="input-wrapper">
                <Mail size={19} />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                />
              </div>

              <label>Password</label>
              <div className="input-wrapper">
                <Lock size={19} />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  minLength={8}
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={19} /> : <Eye size={19} />}
                </button>
              </div>

              {error && <p className="error-message">{error}</p>}
              {message && <p className="success-message">{message}</p>}

              <button className="login-button" disabled={loading} type="submit">
                {loading
                  ? "Please wait..."
                  : isRegister
                    ? "Create Account"
                    : "Sign In"}
                <ArrowRight size={19} />
              </button>
            </form>

            <p className="switch-auth">
              {isRegister ? "Already have an account?" : "New to CivicPulse AI?"}
              <button
                type="button"
                onClick={() => {
                  setIsRegister(!isRegister);
                  setError("");
                  setMessage("");
                }}
              >
                {isRegister ? " Sign in" : " Create account"}
              </button>
            </p>

            <div className="login-footer">
              <ShieldCheck size={16} />
              Secure access • Protected authentication
            </div>
          </section>
        </main>

        <footer className="app-footer">
          © 2026 CivicPulse AI. Building smarter communities together.
        </footer>
      </div>
    );
  }

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <ShieldCheck size={30} />
          <div>
            <strong>CivicPulse AI</strong>
            <small>SMART GOVERNANCE</small>
          </div>
        </div>

        <div className="sidebar-user">
          <div className="avatar">{user.name?.charAt(0)?.toUpperCase()}</div>
          <div>
            <strong>{user.name}</strong>
            <small>{user.role}</small>
          </div>
        </div>

        <p className="menu-caption">WORKSPACE</p>

        <button
          className={page === "dashboard" ? "side-link selected" : "side-link"}
          onClick={() => {
            setPage("dashboard");
            if (user.role === "citizen") loadComplaints();
            else loadAdminComplaints();
          }}
        >
          <BarChart3 size={18} /> Dashboard
        </button>

        {user.role === "citizen" ? (
          <>
            <button
              className={page === "new" ? "side-link selected" : "side-link"}
              onClick={() => {
                setPage("new");
                setError("");
                setMessage("");
              }}
            >
              <PlusCircle size={18} /> Submit Complaint
            </button>

            <button
              className={page === "history" ? "side-link selected" : "side-link"}
              onClick={() => {
                setPage("history");
                loadComplaints();
              }}
            >
              <ClipboardList size={18} /> My Complaints
            </button>
          </>
        ) : (
          <button
            className={page === "update" ? "side-link selected" : "side-link"}
            onClick={() => {
              setPage("update");
              setError("");
              setMessage("");
            }}
          >
            <RefreshCw size={18} /> Update Status
          </button>
        )}

        <div className="sidebar-bottom">
          <button className="side-link logout-link" onClick={logout}>
            <LogOut size={18} /> Sign Out
          </button>
        </div>
      </aside>

      <main className="dashboard-main">
        <header className="dashboard-topbar">
          <div>
            <span className="eyebrow">CIVICPULSE WORKSPACE</span>
            <h1>
              {page === "new"
                ? "Submit a Complaint"
                : page === "history"
                  ? "My Complaints"
                  : page === "update"
                    ? "Update Complaint Status"
                    : "Dashboard"}
            </h1>
          </div>
          <div className="topbar-user">
            <span className="online-dot" /> {user.name}
          </div>
        </header>

        {error && (
          <div className="alert error-alert">
            <AlertCircle size={18} /> {error}
          </div>
        )}

        {message && (
          <div className="alert success-alert">
            <CheckCircle size={18} /> {message}
          </div>
        )}

        {/* CITIZEN DASHBOARD */}
        {page === "dashboard" && user.role === "citizen" && (
          <>
            <section className="welcome-banner">
              <div>
                <span>WELCOME TO CIVICPULSE AI</span>
                <h2>Hello, {user.name}!</h2>
                <p>Report issues in your community and track their resolution.</p>
              </div>
              <button
                className="banner-button"
                onClick={() => {
                  setPage("new");
                  setMessage("");
                }}
              >
                <PlusCircle size={18} /> New Complaint
              </button>
            </section>

            <section className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon blue"><ClipboardList /></div>
                <span>Total Complaints</span>
                <strong>{total}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon orange"><Clock /></div>
                <span>Open Complaints</span>
                <strong>{citizenOpen}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon green"><CheckCircle /></div>
                <span>Resolved</span>
                <strong>{citizenResolved}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon red"><AlertTriangle /></div>
                <span>High Priority</span>
                <strong>{citizenHighPriority}</strong>
              </div>
            </section>

            <section className="panel">
              <div className="panel-heading">
                <div>
                  <h3>Recent Complaints</h3>
                  <p>Your latest submitted civic issues</p>
                </div>
                <button className="text-button" onClick={loadComplaints}>
                  <RefreshCw size={15} /> Refresh
                </button>
              </div>

              <ComplaintTable
                complaints={complaints.slice(0, 5)}
                loading={loadingComplaints}
                request={request}
              />
            </section>
          </>
        )}

        {/* ADMIN / OFFICER ANALYTICS DASHBOARD */}
        {page === "dashboard" && user.role !== "citizen" && (
          <>
            <section className="welcome-banner">
              <div>
                <span>SMART GOVERNANCE OVERVIEW</span>
                <h2>Welcome, {user.name}</h2>
                <p>Monitor civic complaints, department workload and resolution progress.</p>
              </div>
              <button
                className="banner-button"
                onClick={loadAdminComplaints}
                disabled={loadingAdminComplaints}
              >
                <RefreshCw size={17} />
                {loadingAdminComplaints ? "Refreshing..." : "Refresh Data"}
              </button>
            </section>

            <section className="stats-grid admin-stats-grid">
              <div className="stat-card">
                <div className="stat-icon blue"><ClipboardList /></div>
                <span>Total Complaints</span>
                <strong>{adminTotal}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon orange"><Clock /></div>
                <span>Pending</span>
                <strong>{adminStatusCounts.pending}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon blue"><Activity /></div>
                <span>In Progress</span>
                <strong>{adminStatusCounts.inProgress}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon green"><CheckCircle /></div>
                <span>Resolved</span>
                <strong>{adminStatusCounts.resolved}</strong>
              </div>

              <div className="stat-card">
                <div className="stat-icon red"><AlertTriangle /></div>
                <span>High Priority</span>
                <strong>{adminHighPriority}</strong>
              </div>
            </section>

            <section className="analytics-grid">
              <div className="panel analytics-panel">
                <div className="panel-heading">
                  <div>
                    <h3>Complaint Status Overview</h3>
                    <p>Distribution of all recorded complaints</p>
                  </div>
                  <Activity size={20} />
                </div>

                <div className="resolution-summary">
                  <div>
                    <strong>{resolutionRate}%</strong>
                    <span>Resolution rate</span>
                  </div>
                  <div className="resolution-track">
                    <div
                      className="resolution-fill"
                      style={{ width: `${resolutionRate}%` }}
                    />
                  </div>
                </div>

                <div className="status-chart">
                  {[
                    { label: "Pending", value: adminStatusCounts.pending, color: "#e9a23b" },
                    { label: "In Progress", value: adminStatusCounts.inProgress, color: "#4389dc" },
                    { label: "Resolved", value: adminStatusCounts.resolved, color: "#29a36a" },
                    { label: "Rejected", value: adminStatusCounts.rejected, color: "#dc6262" },
                  ].map(item => {
                    const percent = adminTotal
                      ? (item.value / adminTotal) * 100
                      : 0;

                    return (
                      <div className="status-chart-row" key={item.label}>
                        <div className="chart-label">
                          <span>
                            <i style={{ background: item.color }} />
                            {item.label}
                          </span>
                          <strong>{item.value}</strong>
                        </div>
                        <div className="chart-track">
                          <div
                            className="chart-fill"
                            style={{
                              width: `${percent}%`,
                              background: item.color,
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="panel analytics-panel">
                <div className="panel-heading">
                  <div>
                    <h3>Department Workload</h3>
                    <p>Complaints assigned to each department</p>
                  </div>
                  <Building2 size={20} />
                </div>

                {departmentStats.length === 0 ? (
                  <p className="empty-state">No department data available yet.</p>
                ) : (
                  <div className="department-chart">
                    {departmentStats.map(([department, count]) => (
                      <div className="department-row" key={department}>
                        <div className="department-label">
                          <span title={department}>{department}</span>
                          <strong>{count}</strong>
                        </div>
                        <div className="chart-track">
                          <div
                            className="chart-fill department-fill"
                            style={{
                              width: `${(count / maxDepartmentCount) * 100}%`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>

            <section className="panel">
              <div className="panel-heading">
                <div>
                  <h3>All Recent Complaints</h3>
                  <p>Latest complaints across the platform</p>
                </div>
                <button className="text-button" onClick={loadAdminComplaints}>
                  <RefreshCw size={15} /> Refresh
                </button>
              </div>

              <ComplaintTable
                complaints={adminComplaints.slice(0, 8)}
                loading={loadingAdminComplaints}
                request={request}
              />
            </section>
          </>
        )}

        {/* CITIZEN SUBMISSION */}
        {page === "new" && user.role === "citizen" && (
          <section className="panel form-panel">
            <div className="panel-heading">
              <div>
                <h3>Report a Civic Issue</h3>
                <p>
                  Provide details so the AI agents can analyze and route
                  your complaint.
                </p>
              </div>
            </div>

            <form className="complaint-form" onSubmit={submitComplaint}>
              <label>Complaint Title</label>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Example: Water leakage near main road"
                required
                minLength={5}
                maxLength={200}
              />

              <label>Issue Description</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe the issue clearly..."
                required
                minLength={10}
                rows={5}
              />

              <label>Location</label>
              <input
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="Street, area, city"
                required
                minLength={3}
                maxLength={255}
              />

              <button className="login-button submit-button" disabled={loading}>
                <Send size={18} />
                {loading ? "Analyzing and submitting..." : "Submit Complaint"}
              </button>
            </form>

            {latestAnalysis && (
              <div className="analysis-result">
                <h3><Activity size={19} /> AI Analysis Result</h3>
                <pre>{JSON.stringify(latestAnalysis, null, 2)}</pre>
              </div>
            )}
          </section>
        )}

        {/* CITIZEN COMPLAINT HISTORY */}
        {page === "history" && user.role === "citizen" && (
          <section className="panel">
            <div className="panel-heading">
              <div>
                <h3>Complaint History</h3>
                <p>Track the status of your submitted complaints.</p>
              </div>
              <button className="text-button" onClick={loadComplaints}>
                <RefreshCw size={15} /> Refresh
              </button>
            </div>

            <ComplaintTable
              complaints={complaints}
              loading={loadingComplaints}
              request={request}
            />
          </section>
        )}

        {/* OFFICER / ADMIN STATUS UPDATE */}
        {page === "update" && user.role !== "citizen" && (
          <section className="panel form-panel">
            <div className="panel-heading">
              <div>
                <h3>Update Complaint</h3>
                <p>Enter the complaint database ID and update its resolution status.</p>
              </div>
            </div>

            <form className="complaint-form" onSubmit={updateStatus}>
              <label>Complaint Database ID</label>
              <input
                type="number"
                min="1"
                value={updateId}
                onChange={e => setUpdateId(e.target.value)}
                placeholder="Example: 2"
                required
              />

              <label>New Status</label>
              <select
                value={newStatus}
                onChange={e => setNewStatus(e.target.value)}
              >
                <option value="under_review">Under Review</option>
                <option value="assigned">Assigned</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="rejected">Rejected</option>
              </select>

              <label>Remarks</label>
              <textarea
                value={remarks}
                onChange={e => setRemarks(e.target.value)}
                placeholder="Enter update remarks..."
                rows={4}
              />

              <button className="login-button submit-button" disabled={loading}>
                <RefreshCw size={18} />
                {loading ? "Updating..." : "Update Status"}
              </button>
            </form>
          </section>
        )}
      </main>
    </div>
  );
}

function ComplaintTable({ complaints, loading, request }) {
  if (loading) {
    return <p className="empty-state">Loading complaints...</p>;
  }

  if (!complaints.length) {
    return (
      <div className="empty-state">
        <ClipboardList size={35} />
        <strong>No complaints yet</strong>
        <span>Your submitted complaints will appear here.</span>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <table className="complaint-table">
        <thead>
          <tr>
            <th>Complaint</th>
            <th>Category</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Location</th>
            <th>AI Analysis</th>
          </tr>
        </thead>

        <tbody>
          {complaints.map(item => (
            <tr key={item.id}>
              <td>
                <strong>{item.title}</strong>
                <small>{item.complaint_number}</small>
              </td>
              <td>{item.category || "Pending"}</td>
              <td>
                <span className={`priority ${String(item.priority || "medium").toLowerCase()}`}>
                  {item.priority || "Medium"}
                </span>
              </td>
              <td>
                <span className={`status-pill ${normalizeStatus(item.status).replaceAll("_", "-")}`}>
                  {String(item.status || "submitted").replaceAll("_", " ")}
                </span>
              </td>
              <td>{item.location}</td>
              <td>
                <ComplaintAnalysis complaintId={item.id} request={request} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ComplaintAnalysis({ complaintId, request }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);

  const loadAnalysis = async () => {
    if (loading || loaded) return;

    setLoading(true);
    setError("");

    try {
      // Use the numeric database ID, not the public CP complaint number.
      const data = await request(`/complaints/${complaintId}/analysis`);
      setAnalysis(data);
      setLoaded(true);
    } catch (err) {
      setError(err.message || "Unable to load saved AI analysis.");
    } finally {
      setLoading(false);
    }
  };

  const records = Array.isArray(analysis?.ai_analysis)
    ? analysis.ai_analysis
    : [];

  const displayValue = value => {
    if (value === null || value === undefined) return "Not available";
    if (typeof value === "string") return value;
    return JSON.stringify(value, null, 2);
  };

  return (
    <div className="saved-ai-analysis">
      <details
        onToggle={event => {
          if (event.currentTarget.open) loadAnalysis();
        }}
      >
        <summary>
          <Brain size={16} />
          View Analysis
        </summary>

        <div className="saved-ai-content">
          {loading && (
            <p className="empty-state">Loading saved AI analysis...</p>
          )}

          {error && (
            <div className="error-message">
              <p>{error}</p>
              <button
                type="button"
                className="text-button"
                onClick={() => {
                  setLoaded(false);
                  setError("");
                  loadAnalysis();
                }}
              >
                <RefreshCw size={14} /> Retry
              </button>
            </div>
          )}

          {loaded && (
            <>
              <h4>
                <Activity size={17} /> Saved AI Analysis
              </h4>

              <p>
                Analysis records:{" "}
                <strong>{analysis?.total_agents ?? records.length}</strong>
              </p>

              {records.length === 0 && (
                <p className="empty-state">
                  No saved AI analysis records are available for this complaint.
                </p>
              )}

              {records.map((record, index) => (
                <div className="ai-record-card" key={`${record.agent_name || "agent"}-${index}`}>
                  <h5>
                    <Brain size={15} />
                    {record.agent_name || `Analysis Agent ${index + 1}`}
                  </h5>

                  {record.input_summary && (
                    <p>
                      <strong>Input:</strong> {record.input_summary}
                    </p>
                  )}

                  <p><strong>Output:</strong></p>
                  <pre>{displayValue(record.output_data)}</pre>

                  {record.confidence !== null &&
                    record.confidence !== undefined && (
                      <p>
                        <strong>Confidence:</strong>{" "}
                        {typeof record.confidence === "number"
                          ? `${(record.confidence * 100).toFixed(1)}%`
                          : displayValue(record.confidence)}
                      </p>
                    )}

                  {record.source_references && (
                    <div className="ai-sources">
                      <strong>
                        <FileText size={14} /> Knowledge Sources
                      </strong>
                      <pre>{displayValue(record.source_references)}</pre>
                    </div>
                  )}

                  {record.created_at && (
                    <small>
                      Saved: {new Date(record.created_at).toLocaleString()}
                    </small>
                  )}
                </div>
              ))}

              <p className="ai-review-note">
                <AlertCircle size={15} />
                AI recommendations are decision-support information.
                Department assignment and resolution require human oversight.
              </p>

              <p className="ai-disclaimer">
                Retrieved knowledge documents are academic demonstration
                materials and should not be treated as verified official
                municipal regulations.
              </p>
            </>
          )}
        </div>
      </details>
    </div>
  );
}

export default App;
