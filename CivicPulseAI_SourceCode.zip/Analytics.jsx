
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

import { Bar, Doughnut } from "react-chartjs-2";

import {
  ClipboardList,
  Clock,
  CheckCircle,
  AlertTriangle,
} from "lucide-react";

import "./Analytics.css";

// Register Chart.js components.
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

function Analytics({ complaints = [] }) {
  // Safely handle complaint data.
  const complaintList = Array.isArray(complaints)
    ? complaints
    : [];

  // Normalize backend values.
  const getStatus = (complaint) =>
    String(complaint.status || "submitted")
      .trim()
      .toLowerCase();

  const getPriority = (complaint) =>
    String(complaint.priority || "medium")
      .trim()
      .toLowerCase();

  const getCategory = (complaint) =>
    String(complaint.category || "Unclassified")
      .trim();

  // Calculate statistics using actual complaint records.
  const total = complaintList.length;

  const resolved = complaintList.filter(
    (complaint) => getStatus(complaint) === "resolved"
  ).length;

  const pending = complaintList.filter(
    (complaint) =>
      !["resolved", "rejected"].includes(getStatus(complaint))
  ).length;

  const highPriority = complaintList.filter(
    (complaint) =>
      ["high", "critical"].includes(getPriority(complaint))
  ).length;

  // --------------------------------
  // COMPLAINT STATUS BAR CHART
  // --------------------------------

  const statusNames = [
    "submitted",
    "under_review",
    "assigned",
    "in_progress",
    "resolved",
    "rejected",
  ];

  const statusLabels = statusNames.map((status) =>
    status
      .replaceAll("_", " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase())
  );

  const statusData = statusNames.map(
    (status) =>
      complaintList.filter(
        (complaint) => getStatus(complaint) === status
      ).length
  );

  const barData = {
    labels: statusLabels,
    datasets: [
      {
        label: "Number of Complaints",
        data: statusData,
        backgroundColor: "#2563EB",
        hoverBackgroundColor: "#1D4ED8",
        borderRadius: 7,
        maxBarThickness: 48,
      },
    ],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: 800,
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: true,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
          stepSize: 1,
        },
        grid: {
          color: "#edf1f7",
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          maxRotation: 35,
          minRotation: 0,
          font: {
            size: 10,
          },
        },
      },
    },
  };

  // --------------------------------
  // COMPLAINT CATEGORY DOUGHNUT CHART
  // --------------------------------

  const categoryMap = new Map();

  complaintList.forEach((complaint) => {
    const category = getCategory(complaint);
    const key = category.toLowerCase();

    categoryMap.set(
      key,
      (categoryMap.get(key) || 0) + 1
    );
  });

  const categoryLabels = Array.from(categoryMap.keys()).map(
    (key) =>
      key.replace(/\b\w/g, (letter) => letter.toUpperCase())
  );

  const categoryData = Array.from(categoryMap.values());

  const doughnutData = {
    labels: categoryLabels,
    datasets: [
      {
        label: "Complaints by Category",
        data: categoryData,
        backgroundColor: [
          "#2563EB",
          "#0D9488",
          "#F59E0B",
          "#DC2626",
          "#7C3AED",
          "#64748B",
          "#0891B2",
        ],
        borderWidth: 3,
        borderColor: "#FFFFFF",
        hoverOffset: 8,
      },
    ],
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: "65%",
    animation: {
      duration: 800,
    },
    plugins: {
      legend: {
        display: true,
        position: "bottom",
        labels: {
          usePointStyle: true,
          padding: 16,
          font: {
            size: 11,
          },
        },
      },
      tooltip: {
        enabled: true,
      },
    },
  };

  // --------------------------------
  // DASHBOARD UI
  // --------------------------------

  return (
    <section className="analytics-section">

      {/* Heading */}
      <div className="analytics-heading">
        <div>
          <h2>Complaint Analytics</h2>
          <p>
            Statistics based on your submitted complaints
          </p>
        </div>

        <span className="analytics-live">
          Actual Data
        </span>
      </div>

      {/* Statistics Cards */}
      <div className="analytics-stats">

        <div className="analytics-card">
          <div className="analytics-icon blue">
            <ClipboardList size={21} />
          </div>

          <span>Total Complaints</span>
          <strong>{total}</strong>
        </div>

        <div className="analytics-card">
          <div className="analytics-icon orange">
            <Clock size={21} />
          </div>

          <span>Pending Complaints</span>
          <strong>{pending}</strong>
        </div>

        <div className="analytics-card">
          <div className="analytics-icon green">
            <CheckCircle size={21} />
          </div>

          <span>Resolved Complaints</span>
          <strong>{resolved}</strong>
        </div>

        <div className="analytics-card">
          <div className="analytics-icon red">
            <AlertTriangle size={21} />
          </div>

          <span>High-Priority Complaints</span>
          <strong>{highPriority}</strong>
        </div>

      </div>

      {/* Charts */}
      <div className="analytics-charts">

        {/* Status Bar Chart */}
        <div className="analytics-chart-panel">
          <h3>Complaint Status Overview</h3>

          <p>
            Distribution by current complaint status
          </p>

          <div className="chart-container">
            {total > 0 ? (
              <Bar
                data={barData}
                options={barOptions}
              />
            ) : (
              <div className="chart-empty">
                No complaint data available yet.
              </div>
            )}
          </div>
        </div>

        {/* Category Doughnut Chart */}
        <div className="analytics-chart-panel">
          <h3>Complaint Categories</h3>

          <p>
            Distribution by complaint category
          </p>

          <div className="chart-container doughnut-container">
            {categoryData.length > 0 ? (
              <Doughnut
                data={doughnutData}
                options={doughnutOptions}
              />
            ) : (
              <div className="chart-empty">
                No category data available yet.
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Empty State */}
      {total === 0 && (
        <p className="analytics-note">
          Analytics will update automatically when you submit complaints.
        </p>
      )}

    </section>
  );
}

export default Analytics;
