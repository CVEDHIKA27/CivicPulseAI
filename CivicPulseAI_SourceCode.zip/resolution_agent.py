
from datetime import datetime, timezone


VALID_STATUSES = [
    "submitted",
    "under_review",
    "assigned",
    "in_progress",
    "resolved",
    "rejected"
]


def track_resolution(
    complaint_id: str,
    current_status: str = "submitted",
    new_status: str = None,
    remarks: str = ""
) -> dict:
    """
    Resolution Tracking Agent.
    Validates and records complaint status transitions.
    """

    if not complaint_id or not complaint_id.strip():
        raise ValueError("Complaint ID is required.")

    if current_status not in VALID_STATUSES:
        raise ValueError("Invalid current complaint status.")

    if new_status is None:
        return {
            "agent": "Resolution Tracking Agent",
            "complaint_id": complaint_id,
            "current_status": current_status,
            "history": [],
            "message": "Current status retrieved."
        }

    if new_status not in VALID_STATUSES:
        raise ValueError("Invalid new complaint status.")

    if new_status == current_status:
        raise ValueError("New status must differ from current status.")

    return {
        "agent": "Resolution Tracking Agent",
        "complaint_id": complaint_id,
        "previous_status": current_status,
        "new_status": new_status,
        "remarks": remarks.strip(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "requires_human_approval": True,
        "message": "Status change prepared for approval."
    }
