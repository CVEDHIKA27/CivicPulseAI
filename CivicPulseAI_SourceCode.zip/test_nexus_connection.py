import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

model = os.getenv("NEXUS_MODEL")

client = OpenAI(
    api_key=os.getenv("NEXUS_API_KEY"),
    base_url=os.getenv("NEXUS_BASE_URL")
)

print("Testing Nexus model:", model)

try:
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": "Reply with exactly: CivicPulse Nexus Connected"}
        ]
    )

    print("NEXUS CHAT SUCCESS!")
    print("Response:", response.choices[0].message.content)

except Exception as error:
    print("NEXUS CHAT FAILED")
    print("Error type:", type(error).__name__)
    print("HTTP status:", getattr(error, "status_code", "Unknown"))
    print("Details:", str(error)[:1000])