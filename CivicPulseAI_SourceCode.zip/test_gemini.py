﻿from dotenv import load_dotenv
from google import genai
import os

load_dotenv(override=True)

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise RuntimeError("Gemini API key is missing")

client = genai.Client(api_key=api_key)

try:
    response = client.models.generate_content(
        model="gemini-3.5-flash-lite",
        contents="Reply with exactly: CivicPulse AI Gemini connection successful"
    )
    print("Gemini API connection successful!")
    print("Response:", response.text)

except Exception as error:
    print("Gemini API test failed.")
    print("Error:", str(error)[:500])
