
import json
import os
import re

from dotenv import load_dotenv
from google import genai

load_dotenv()


def _local_understanding(description: str, location: str = "") -> dict:
    """Fallback complaint understanding without an API."""
    normalized_text = re.sub(r"\s+", " ", description.strip())

    keywords = {
        "water": ["water", "pipeline", "leakage", "drinking water"],
        "road": ["road", "pothole", "street damage", "traffic"],
        "waste": ["garbage", "waste", "rubbish", "dustbin"],
        "electricity": ["electricity", "power cut", "street light", "electric pole"],
        "drainage": ["drainage", "sewage", "blocked drain", "overflow"]
    }

    lower_text = normalized_text.lower()

    detected_topics = [
        category
        for category, words in keywords.items()
        if any(word in lower_text for word in words)
    ]

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": normalized_text,
        "location": location.strip(),
        "detected_topics": detected_topics,
        "summary": normalized_text[:200],
        "status": "understood",
        "method": "local_keyword_fallback",
        "requires_review": True
    }


def understand_complaint(description: str, location: str = "") -> dict:
    """Understand a complaint using Gemini, with local fallback."""

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    normalized_text = re.sub(r"\s+", " ", description.strip())

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        return _local_understanding(normalized_text, location)

    try:
        client = genai.Client(api_key=api_key)

        prompt = f"""
You are the Complaint Understanding Agent for CivicPulse AI.

Analyze this municipal complaint.

Complaint: {normalized_text}
Location: {location}

Return ONLY valid JSON with these fields:
{{
  "summary": "short complaint summary",
  "detected_topics": ["water", "road", "waste", "electricity", "drainage"],
  "requires_review": true
}}

Use only relevant categories from the list.
Do not invent facts or locations.
Set requires_review to true when the complaint is unclear or urgent.
"""

        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt
        )

        if not response.text:
            raise ValueError("Gemini returned an empty response.")

        result = json.loads(response.text)

        allowed_topics = {
            "water", "road", "waste", "electricity", "drainage"
        }

        topics = result.get("detected_topics", [])

        if not isinstance(topics, list):
            raise ValueError("Invalid topics returned by Gemini.")

        topics = [
            topic.lower()
            for topic in topics
            if isinstance(topic, str) and topic.lower() in allowed_topics
        ]

        return {
            "agent": "Complaint Understanding Agent",
            "original_complaint": normalized_text,
            "location": location.strip(),
            "detected_topics": list(dict.fromkeys(topics)),
            "summary": str(
                result.get("summary", normalized_text[:200])
            )[:500],
            "status": "understood",
            "method": "gemini_ai",
            "requires_review": bool(result.get("requires_review", True))
        }

    except Exception:
        return _local_understanding(normalized_text, location)