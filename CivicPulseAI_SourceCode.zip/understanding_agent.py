
import re


def understand_complaint(description: str, location: str = "") -> dict:
    """
    Basic local Complaint Understanding Agent.
    Extracts useful information without requiring an API key.
    """

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    text = description.strip()
    normalized_text = re.sub(r"\s+", " ", text)

    keywords = {
        "water": ["water", "pipeline", "leakage", "drinking water"],
        "road": ["road", "pothole", "street damage", "traffic"],
        "waste": ["garbage", "waste", "rubbish", "dustbin"],
        "electricity": ["electricity", "power cut", "street light", "electric pole"],
        "drainage": ["drainage", "sewage", "blocked drain", "overflow"]
    }

    detected_topics = []

    lower_text = normalized_text.lower()

    for category, words in keywords.items():
        if any(word in lower_text for word in words):
            detected_topics.append(category)

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": normalized_text,
        "location": location.strip(),
        "detected_topics": detected_topics,
        "summary": normalized_text[:200],
        "status": "understood",
        "method": "local_keyword_analysis",
        "requires_review": True
    }
