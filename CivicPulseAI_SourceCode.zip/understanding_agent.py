
import json
import os
import re

from dotenv import load_dotenv
from google import genai
from openai import OpenAI

load_dotenv()

ALLOWED_TOPICS = {
    "water", "road", "waste", "electricity", "drainage"
}

# A topic is accepted only when the complaint contains
# specific evidence for that category.
TOPIC_PATTERNS = {
    "water": [
        r"\bwater\b",
        r"\bwater supply\b",
        r"\bdrinking water\b",
        r"\bpipeline\b",
        r"\bleakage\b",
        r"\bwater leak(?:age)?\b",
    ],
    "road": [
        r"\bpotholes?\b",
        r"\bdamaged road\b",
        r"\bbroken road\b",
        r"\bcracked road\b",
        r"\bstreet damage\b",
        r"\bdamaged pavement\b",
        r"\bbroken pavement\b",
        r"\broad surface\b",
        r"\btraffic congestion\b",
    ],
    "waste": [
        r"\bgarbage\b",
        r"\brubbish\b",
        r"\btrash\b",
        r"\blitter\b",
        r"\bdustbins?\b",
        r"\bsolid waste\b",
        r"\bwaste collection\b",
        r"\bgarbage collection\b",
        r"\bwaste disposal\b",
        r"\bplastic waste\b",
        r"\bfood waste\b",
        r"\buncollected waste\b",
    ],
    "electricity": [
        r"\belectricity\b",
        r"\bpower cut\b",
        r"\bpower outage\b",
        r"\bstreet lights?\b",
        r"\belectric pole\b",
        r"\bpower supply\b",
        r"\bexposed wires?\b",
        r"\bpower failure\b",
    ],
    "drainage": [
        r"\bdrainage\b",
        r"\bsewage\b",
        r"\bblocked drain\b",
        r"\bdrain blockage\b",
        r"\bsewage overflow\b",
        r"\bstagnant wastewater\b",
    ],
}


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _clean_topics(topics, description: str) -> list:
    """Remove AI categories that have no supporting complaint evidence."""

    text = _normalize_text(description)
    cleaned = []

    if not isinstance(topics, list):
        topics = []

    for topic in topics:
        if not isinstance(topic, str):
            continue

        topic = topic.strip().lower()

        if topic not in ALLOWED_TOPICS:
            continue

        patterns = TOPIC_PATTERNS.get(topic, [])

        if any(re.search(pattern, text) for pattern in patterns):
            cleaned.append(topic)

    return list(dict.fromkeys(cleaned))


def _local_understanding(description: str, location: str = "") -> dict:
    """Fallback complaint understanding without an API."""

    normalized_text = re.sub(r"\s+", " ", description.strip())

    detected_topics = []

    for topic, patterns in TOPIC_PATTERNS.items():
        if any(
            re.search(pattern, normalized_text.lower())
            for pattern in patterns
        ):
            detected_topics.append(topic)

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": normalized_text,
        "location": location.strip(),
        "detected_topics": detected_topics,
        "summary": normalized_text[:200],
        "status": "understood",
        "method": "local_keyword_fallback",
        "requires_review": True
    }


def _extract_json(text: str) -> dict:
    """Extract and validate JSON returned by an AI provider."""

    if not text:
        raise ValueError("AI provider returned an empty response.")

    cleaned = text.strip()

    cleaned = re.sub(
        r"^```(?:json)?\s*",
        "",
        cleaned,
        flags=re.IGNORECASE
    )
    cleaned = re.sub(r"\s*```$", "", cleaned)

    result = json.loads(cleaned)

    if not isinstance(result, dict):
        raise ValueError("AI response must be a JSON object.")

    topics = result.get("detected_topics", [])

    if not isinstance(topics, list):
        raise ValueError("Invalid topics returned by AI.")

    return result


def _build_result(
    description: str,
    location: str,
    ai_result: dict,
    method: str
) -> dict:
    """Create a consistent result with evidence-based topic filtering."""

    topics = _clean_topics(
        ai_result.get("detected_topics", []),
        description
    )

    return {
        "agent": "Complaint Understanding Agent",
        "original_complaint": description,
        "location": location.strip(),
        "detected_topics": topics,
        "summary": str(
            ai_result.get("summary", description[:200])
        )[:500],
        "status": "understood",
        "method": method,
        "requires_review": bool(
            ai_result.get("requires_review", True)
        )
    }


def understand_complaint(description: str, location: str = "") -> dict:
    """Understand a complaint using Nexus, Gemini, or local fallback."""

    if not description or not description.strip():
        raise ValueError("Complaint description cannot be empty.")

    normalized_text = re.sub(r"\s+", " ", description.strip())

    prompt = f"""
You are the Complaint Understanding Agent for CivicPulse AI.

Analyze this municipal complaint carefully.

Complaint: {normalized_text}
Location: {location}

Return ONLY valid JSON with these fields:
{{
  "summary": "short complaint summary",
  "detected_topics": [],
  "requires_review": true
}}

Allowed categories:
water, road, waste, electricity, drainage.

Important classification rules:
- Select only categories directly supported by the complaint.
- A location containing the words "Main Road" does NOT mean road damage.
- Water being wasted or leaking is a WATER issue, not solid waste.
- Select waste only for garbage, rubbish, trash, litter, or solid waste.
- Select road only for potholes, damaged roads, broken pavement, or traffic issues.
- Do not invent facts or locations.
- Set requires_review to true when the complaint is unclear or urgent.
"""

    # 1. Try Nexus first.
    nexus_key = os.getenv("NEXUS_API_KEY")
    nexus_base_url = os.getenv("NEXUS_BASE_URL")
    nexus_model = os.getenv("NEXUS_MODEL", "nova-micro")

    if nexus_key and nexus_base_url and nexus_model:
        try:
            client = OpenAI(
                api_key=nexus_key,
                base_url=nexus_base_url,
                timeout=30.0
            )

            response = client.chat.completions.create(
                model=nexus_model,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            response_text = response.choices[0].message.content
            result = _extract_json(response_text)

            return _build_result(
                normalized_text,
                location,
                result,
                "nexus_ai"
            )

        except Exception as error:
            print(
                "Nexus understanding unavailable:",
                type(error).__name__
            )

    # 2. Try Gemini if Nexus is unavailable.
    gemini_key = os.getenv("GEMINI_API_KEY")

    if gemini_key:
        try:
            client = genai.Client(api_key=gemini_key)

            response = client.models.generate_content(
                model="gemini-3.5-flash-lite",
                contents=prompt
            )

            result = _extract_json(response.text)

            return _build_result(
                normalized_text,
                location,
                result,
                "gemini_ai"
            )

        except Exception as error:
            print(
                "Gemini understanding unavailable:",
                type(error).__name__
            )

    # 3. Final local fallback.
    return _local_understanding(normalized_text, location)
