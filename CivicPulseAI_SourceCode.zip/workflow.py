
from backend.app.agents.understanding_agent import understand_complaint
from backend.app.agents.classification_agent import classify_complaint
from backend.app.agents.routing_agent import route_complaint
from backend.app.agents.resolution_agent import track_resolution


def process_complaint(
    description: str,
    location: str,
    complaint_id: str
) -> dict:
    """
    CivicPulse AI - Initial Multi-Agent Workflow.

    1. Understand complaint
    2. Classify complaint
    3. Recommend department
    4. Initialize resolution tracking
    """

    # Agent 1: Understand complaint
    understanding = understand_complaint(
        description,
        location
    )

    # Agent 2: Classify complaint
    classification = classify_complaint(
        description,
        understanding["detected_topics"]
    )

    # Agent 3: Recommend department
    routing = route_complaint(classification)

    # Agent 4: Initialize resolution tracking
    resolution = track_resolution(
        complaint_id,
        current_status="submitted"
    )

    return {
        "project": "CivicPulse AI",
        "complaint_id": complaint_id,
        "understanding_agent": understanding,
        "classification_agent": classification,
        "routing_agent": routing,
        "resolution_agent": resolution,
        "overall_status": "analysis_completed",
        "requires_human_review": (
            understanding["requires_review"]
            or classification["requires_review"]
            or routing["requires_human_approval"]
        )
    }
