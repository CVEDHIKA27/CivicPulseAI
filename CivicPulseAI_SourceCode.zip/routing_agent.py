
def route_complaint(classification_result: dict) -> dict:
    """
    Department Routing Agent.
    Recommends the responsible municipal department.
    """

    if not isinstance(classification_result, dict):
        raise ValueError("Classification result must be a dictionary.")

    category = classification_result.get("primary_category", "unknown")

    routing_rules = {
        "water": ("Water Supply Department", "Water Supply Officer"),
        "road": ("Roads and Public Works Department", "Public Works Officer"),
        "waste": ("Sanitation Department", "Sanitation Officer"),
        "electricity": ("Electricity Department", "Electrical Maintenance Officer"),
        "drainage": ("Drainage Department", "Drainage Officer")
    }

    route = routing_rules.get(category)

    if not route:
        return {
            "agent": "Department Routing Agent",
            "category": category,
            "routing_status": "manual_review_required",
            "department": None,
            "officer_role": None,
            "requires_human_approval": True
        }

    return {
        "agent": "Department Routing Agent",
        "category": category,
        "routing_status": "recommended",
        "department": route[0],
        "officer_role": route[1],
        "priority": classification_result.get("priority", "medium"),
        "requires_human_approval": True
    }
