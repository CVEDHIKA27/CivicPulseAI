from sqlalchemy import (
    Column, Integer, String, Text,
    DateTime, ForeignKey, JSON
)
from sqlalchemy.sql import func

from backend.app.core.database import Base


# 1. USERS TABLE
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(30), default="citizen")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# 2. DEPARTMENTS TABLE
class Department(Base):
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)


# 3. COMPLAINTS TABLE
class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(Integer, primary_key=True, index=True)
    complaint_number = Column(String(30), unique=True, nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100))
    priority = Column(String(30), default="medium")
    status = Column(String(30), default="submitted")
    location = Column(String(255))
    image_path = Column(String(500))

    citizen_id = Column(Integer, ForeignKey("users.id"))
    department_id = Column(Integer, ForeignKey("departments.id"))

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )


# 4. COMPLAINT HISTORY TABLE
class ComplaintHistory(Base):
    __tablename__ = "complaint_history"

    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"), nullable=False)
    status = Column(String(30), nullable=False)
    remarks = Column(Text)
    updated_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# 5. AI ANALYSIS TABLE
class AIAnalysis(Base):
    __tablename__ = "ai_analysis"

    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"), nullable=False)
    agent_name = Column(String(100), nullable=False)
    input_summary = Column(Text)
    output_data = Column(JSON)
    confidence = Column(String(20))
    source_references = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())